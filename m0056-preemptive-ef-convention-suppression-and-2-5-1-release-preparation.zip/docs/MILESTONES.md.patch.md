# MILESTONES.md Update

Append after M0055:

```text
- [M0056 - Preemptive EF Convention Suppression and 2.5.1 Release Preparation](milestones/m0056-preemptive-ef-convention-suppression-and-2-5-1-release-preparation.md)
```
