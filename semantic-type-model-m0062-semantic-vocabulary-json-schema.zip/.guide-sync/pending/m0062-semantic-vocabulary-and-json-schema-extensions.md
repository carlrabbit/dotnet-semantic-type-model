# Documentation Sync Hint — M0062 Semantic Vocabulary and JSON Schema Extensions

## Source

- `docs/milestones/m0062-semantic-vocabulary-and-json-schema-extensions.md`

## Status

Pending.

## Purpose

M0062 directly updates authoritative specs and consumer documentation that would otherwise become false. This hint exists only for residual normalization discovered after implementation.

Ordinary implementation agents are not required to read this file.

## Residual Sync Checks

After implementation and direct documentation updates, verify that active documentation contains no stale claims about:

- `Relationship` as a canonical semantic primitive;
- `SemanticRelationshipAttribute`;
- `InferRelationships` or an equivalent generator option;
- canonical relationship cardinality/delete-behavior contracts;
- Power BI relationship derivation from canonical relationship definitions;
- JSON Editor compatibility mode;
- `JsonSchemaUiExportOptions`;
- `JsonSchemaUiMode`;
- `UiHintOptions` widget inference/strict widget vocabulary when those surfaces are removed;
- `jsonEditor.*` as active supported annotation vocabulary;
- old mixed mutability values such as `InitOnly`, `ReadOnly`, or `WriteOnly` as canonical semantic mutability.

Also verify that current docs consistently describe:

- optional lifecycle mutability;
- `[SemanticMutable]` and `[SemanticImmutable]`;
- declared versus effective mutability;
- JSON Schema `x-stm`;
- `x-stm.technicalDescription`;
- `x-stm.ui` open pass-through behavior;
- exact initial `x-stm` vocabulary and the ability to disable semantic annotations.

## Likely Documentation Surfaces

- `README.md`
- `docs/TERMINOLOGY.md`
- `docs/SPECS.md`
- relevant `docs/specs/*`
- `docs/PUBLIC-DOCS.md` if routing changes
- `public-docs/configuration.md`
- `public-docs/concepts.md` or equivalent semantic guide
- `public-docs/guides/json-schema.md`
- `public-docs/guides/projection-capabilities.md`
- `public-docs/guides/power-bi.md`
- `public-docs/diagnostics/*`
- `public-docs/nuget/SemanticTypeModel.md`
- `public-docs/release-notes.md`

Delete the obsolete JSON Editor compatibility guide rather than retaining it as an archive if it is no longer active product truth.

## Completion Criteria

- all directly false authority/public docs were corrected during M0062;
- remaining text is normalized consistently;
- no removed relationship/editor/mutability API is documented as supported;
- this hint is deleted.

## Blockers

None known at planning time.
