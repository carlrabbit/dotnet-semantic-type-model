# Milestones

## Purpose

Milestones are active implementation work orders. They are deleted after durable outcomes are synchronized; Git retains completed history.

## Current

- `M0062` — `docs/milestones/m0062-semantic-vocabulary-and-json-schema-extensions.md`

M0062 tightens the canonical semantic vocabulary, replaces mixed CLR/access mutability with optional lifecycle mutability, removes general relationship semantics, and simplifies JSON Schema around a small `x-stm` semantic extension with open UI pass-through metadata.

## Next Number

```text
M0063
```

Never restart or reuse milestone numbers.

## Lifecycle

```text
plan -> implement -> synchronize durable truth -> validate -> complete -> delete completed milestone
```

Promote current behavior to specifications, structural outcomes to architecture, durable rationale to decisions, and consumer-visible behavior to public documentation before deleting a completed milestone. Do not archive milestone files in the working tree.
