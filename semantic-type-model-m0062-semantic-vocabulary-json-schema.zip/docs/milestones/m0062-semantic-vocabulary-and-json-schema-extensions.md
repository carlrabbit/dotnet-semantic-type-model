# M0062 — Semantic Vocabulary and JSON Schema Extensions

## Goal

Tighten the canonical Semantic Type Model vocabulary and make JSON Schema preserve a deliberate subset of STM-only semantics without coupling the projection to a specific editor.

M0062 performs one broad, breaking, systematic transformation:

1. replace the current mixed CLR/access `Mutability` concept with optional lifecycle mutability;
2. add explicit code-first type/property mutability declarations;
3. remove the current general relationship semantic model completely;
4. replace JSON Editor-specific UI/export behavior with open `ui.*` pass-through metadata;
5. introduce optional JSON Schema `x-stm` semantic annotations;
6. include technical descriptions in the initial `x-stm` vocabulary;
7. update all directly affected canonical/projection/public contracts and tests without compatibility shims.

## Repository Assumptions

| Dimension | Assumption |
|---|---|
| Repository | `carlrabbit/dotnet-semantic-type-model` |
| Profile | `base` + `dotnet-library` |
| Repository role | capability-provider |
| Maturity | published-maintenance |
| Guide-system metadata | v0.6.0 |
| Execution mode | `ai-executed-broad` |
| Documentation synchronization | separate pass for residual normalization only |
| Release readiness | separate milestone/pass |
| Formal human review | none for M0062 |

The explicit M0062 execution mode overrides the profile's default implementation mode for this milestone only.

`.guide-profile.json` is planning metadata and is not required reading for the implementation agent.

## Execution Mode

`ai-executed-broad`

This mode is appropriate because:

- the public API direction is approved;
- the semantic boundary is explicit;
- breaking removal is intentional;
- the transformation is systematic across canonical contracts, extraction, generators, projections, tests, and docs;
- validation is deterministic;
- no unresolved UX/visual/creative acceptance is required.

Do not split the implementation into artificial human-sized sub-milestones.

## Required Authority

Read only these repository-local authority documents before implementation:

- `AGENTS.md`
- `docs/TERMINOLOGY.md`
- `docs/SPECS.md`
- `docs/specs/core-semantic-vocabulary.md`
- `docs/specs/current-canonical-model-surface.md`
- `docs/specs/audience-specific-description-semantics.md`
- `docs/specs/type-model-dotnet-attributes.md`
- `docs/specs/type-model-ui-hints.md`
- `docs/specs/type-model-compile-time-generator.md`
- `docs/specs/json-schema-domain-model-and-export.md`
- `docs/specs/type-model-projection-capabilities.md`
- `docs/specs/type-model-powerbi-tom-projection.md`
- `docs/ENGINEERING.md`
- `docs/engineering/command-contract.md`
- `docs/PUBLIC-DOCS.md`
- `docs/MILESTONES.md`
- `docs/decisions/general-relationships-are-not-canonical-semantics.md`
- `docs/decisions/json-schema-uses-x-stm-for-selected-semantics.md`

Do not read the external guide repository during implementation.

Do not require ordinary implementation work to read `.guide-profile.json` or `.guide-sync/`.

## Scope

### In scope

- canonical lifecycle mutability;
- `.NET` authoring/extraction/generation for lifecycle mutability;
- complete removal of general canonical relationship APIs and inference;
- relationship-removal fallout across Core, generators, manifests, query/inspection, projection capability declarations, Power BI, tests, samples, docs, and diagnostics;
- JSON Schema domain-model/export cleanup;
- open `ui.*` annotation transport;
- initial `x-stm` vocabulary;
- direct updates to specs, terminology, diagnostics, public docs, and examples made false by the implementation;
- focused and aggregate validation of the capability-provider package suite.

### Out of scope

- replacement relationship semantics;
- EF navigation or relationship inference;
- new Power BI relationship semantics;
- changes to ownership semantics;
- changes to keys except JSON Schema preservation;
- changes to `EntityRole.ValueObject` versus `IsValueObject`;
- changes to computed-member semantics;
- changes to discriminator semantics;
- changes to custom constraints;
- generic assignment-authority/system-managed/derived semantics;
- a JSON Schema validation engine;
- JSON Schema import;
- OpenAPI;
- a JSON editor runtime;
- a formal UI framework or closed widget vocabulary;
- `x-stm` protocol versioning or compatibility negotiation;
- release publication;
- guide-system migration;
- formal `.review/` infrastructure;
- engineering-command migration or new resumable-validation infrastructure.

## Focus Area 1 — Replace canonical mutability with optional lifecycle mutability

### Problem

The current canonical `Mutability` enum mixes lifecycle meaning with CLR/access mechanics:

```text
Mutable
Immutable
InitOnly
ReadOnly
WriteOnly
```

and `PropertyDefinition.Mutability` is required.

That incorrectly makes mutability relevant to every property and conflates semantic lifecycle rules with source-language access shape.

### Required canonical contract

Replace the current enum with:

```csharp
public enum SemanticMutability
{
    Mutable,
    Immutable,
}
```

Add nullable declared mutability to object types and properties:

```csharp
SemanticMutability? Mutability
```

The type-level declaration belongs on object semantics/object type definitions, not scalar/enum/array types merely for symmetry.

The property-level declaration belongs on `PropertyDefinition`.

`null` means:

> lifecycle mutability is not part of this semantic contract at this location.

It does **not** mean mutable.

### Resolution semantics

Effective property mutability is:

```text
property.Mutability
    ?? containingObject.Mutability
    ?? unspecified
```

The canonical model must preserve declarations rather than flatten inherited values into every property.

Examples:

```text
type unspecified + property unspecified -> unspecified
type Mutable     + property unspecified -> Mutable
type Immutable   + property unspecified -> Immutable
type Mutable     + property Immutable   -> Immutable
type Immutable   + property Mutable     -> Mutable
```

A mutable property inside an otherwise immutable type is valid and intentional.

Do not reject this pattern.

### CLR/access boundary

Do not infer semantic mutability from:

- `init`;
- setter presence;
- setter accessibility;
- getter-only members;
- `readonly` fields/types;
- record syntax.

CLR access shape may remain extraction/source information where otherwise needed, but it must not be the canonical lifecycle-mutability contract.

### Required removal

Remove the old canonical values and every behavior/test that treats these as semantic mutability:

```text
InitOnly
ReadOnly
WriteOnly
```

Do not retain obsolete aliases.

## Focus Area 2 — Add code-first mutability authoring

Add:

```csharp
[SemanticMutable]
[SemanticImmutable]
```

### Attribute targets

Support:

```text
class
struct
property
field
```

Do not target enum merely for API symmetry.

### Semantics

- type declaration sets the object-level mutability default;
- property/field declaration sets the explicit property override;
- neither attribute means unspecified;
- applying both attributes to one target is invalid and diagnosable;
- duplicate/conflicting mutability declarations must not be silently resolved;
- source-generator and runtime/Roslyn extraction must produce equivalent canonical declarations.

### Diagnostics

Reserve stable diagnostic IDs using the repository diagnostic policy.

Diagnostics must cover at least:

- conflicting mutable/immutable declarations on the same target;
- invalid attribute target/usage if the attribute implementation permits any invalid reflection/Roslyn case;
- malformed generated/transported mutability values if applicable.

Do not reuse retired relationship diagnostic IDs for new mutability diagnostics.

## Focus Area 3 — Remove general relationship semantics completely

Follow `docs/decisions/general-relationships-are-not-canonical-semantics.md`.

### Canonical model removal

Remove, as applicable:

```text
RelationshipId
RelationshipDefinition
RelationshipCardinality
DeleteBehaviorSemantics
ObjectTypeDefinition.Relationships
relationship-specific lookup/query helpers
relationship-specific validation
relationship-specific cloning/transformation
relationship-specific semantic text/inspection
relationship-specific projection capability declarations
```

### Annotation/vocabulary removal

Remove active canonical relationship annotation keys, including the current family equivalent to:

```text
schema.relationship
schema.relationship.target
schema.relationship.principalType
schema.relationship.principalKey
schema.relationship.foreignKey
schema.relationship.cardinality
```

Update the core semantic vocabulary so `Relationship` is no longer listed as a core primitive.

### .NET authoring removal

Remove:

```text
SemanticRelationshipAttribute
InferRelationships
relationship inference
relationship extraction
relationship-specific extraction diagnostics that no longer have another purpose
relationship-specific generator/MSBuild options
```

Remove relationship configuration from public generator/configuration docs.

### Generator/manifest removal

Inspect generated canonical providers and the compile-time semantic manifest.

Remove relationship fields/transport only when they exist solely to transport the removed canonical relationship model.

Do not change the ephemeral-manifest exact-version policy established by M0061.

### Projection fallout

Audit every projection for canonical relationship consumption.

At minimum inspect:

- `SemanticTypeModel.PowerBI`;
- `SemanticTypeModel.EFCore`;
- `SemanticTypeModel.EFCore.Generators`;
- `SemanticTypeModel.JsonSchema`;
- projection capability catalog/tests.

Power BI behavior derived specifically from canonical relationships must be removed or reduced to non-relationship behavior.

Do not replace it with guessed relationships from key names or object references.

EF application-owned relationship configuration remains valid through ordinary EF Core APIs/generated partial hooks; M0062 must not add EF relationship inference.

### Structural concepts that remain

Do not accidentally remove:

- object-valued properties;
- arrays/collections;
- type references needed to describe shape;
- keys;
- ownership;
- aggregate roots;
- envelope semantics.

A collection or object reference is not automatically a semantic relationship.

## Focus Area 4 — Simplify UI annotations to open pass-through metadata

The current UI-hint system is over-specified for the product need.

Replace the current `type-model-ui-hints` contract with a small open annotation transport contract.

### Keep

Keep canonical `ui.*` annotation support.

Existing dedicated authoring semantics remain:

```text
SemanticDisplayName -> ui.title
SemanticCategory    -> ui.category
SemanticOrder       -> ui.order
```

Keep their current intended meanings unless another active spec requires a correction.

### Open pass-through rule

Other `ui.*` annotations are allowed as open JSON-compatible metadata.

They do not need to belong to a closed registry.

The canonical model guarantees:

- namespaced preservation;
- deterministic ordering;
- deterministic JSON-compatible values;
- no silent reinterpretation.

The canonical model does not initially guarantee semantics for arbitrary keys such as `ui.widget`.

### Remove

Remove editor/runtime policy that is no longer justified, including as applicable:

```text
jsonEditor.* active vocabulary
JSON Editor compatibility translation
widget inference
strict widget enumeration
strict unknown-ui-key rejection
JsonSchemaUiExportOptions
JsonSchemaUiMode
UiHintOptions options whose only purpose is inference/closed-vocabulary validation
```

Do not retain editor-specific APIs as compatibility aliases.

## Focus Area 5 — Introduce the JSON Schema `x-stm` extension

Follow `docs/decisions/json-schema-uses-x-stm-for-selected-semantics.md`.

### Export option

Replace ambiguous projection-annotation/UI export switches with one clear semantic-annotation switch.

Preferred public contract:

```csharp
public bool IncludeSemanticAnnotations { get; init; } = true;
```

When `false`, emit plain JSON Schema without `x-stm`.

When `true`, emit the defined `x-stm` members where applicable.

Remove obsolete JSON Editor/UI export mode objects rather than layering the new option beside them.

### Extension shape

Use one object keyword:

```json
{
  "x-stm": {
  }
}
```

Do not emit a family of separate `x-stm-*` top-level keywords.

Do not add an extension version in M0062.

### Initial vocabulary

The initial supported members are exactly:

```text
role
aggregateRoot
mutability
technicalDescription
keys
unit
ui
```

Do not add relationship, computed-member, discriminator, custom-constraint, source/compiler, or projection-specific members opportunistically.

### `role`

Emit the canonical object semantic role when it is explicitly meaningful/non-unspecified.

Use a deterministic lower-case JSON spelling matching the canonical role vocabulary.

Do not emit a separate `valueObject` Boolean merely because the current canonical model also has `IsValueObject`.

### `aggregateRoot`

Emit:

```json
"aggregateRoot": true
```

when aggregate-root semantics are present.

Omit false/default state rather than treating false as an explicit semantic declaration.

### `mutability`

Emit only **declared** mutability at the schema node where it is declared:

```json
"mutability": "mutable"
```

or:

```json
"mutability": "immutable"
```

Do not materialize inherited/effective mutability on every child property.

Example:

```csharp
[SemanticImmutable]
public sealed class Specification
{
    public required string Name { get; init; }

    [SemanticMutable]
    public TechnicalCache Cache { get; set; } = new();
}
```

must conceptually export:

```json
{
  "x-stm": {
    "mutability": "immutable"
  },
  "properties": {
    "name": {
      "type": "string"
    },
    "cache": {
      "x-stm": {
        "mutability": "mutable"
      }
    }
  }
}
```

### `technicalDescription`

Canonical `TechnicalDescription` is an important preserved semantic.

When present on an emitted type/property schema node, emit:

```json
"x-stm": {
  "technicalDescription": "..."
}
```

Do not map it to standard JSON Schema `description`.

Standard `description` continues to use canonical `UserDescription` according to `audience-specific-description-semantics.md`.

Do not fall back from missing user description to technical description.

### `keys`

Preserve canonical object key definitions as structured object-level metadata.

Conceptual shape:

```json
"x-stm": {
  "keys": [
    {
      "name": "Primary",
      "kind": "primary",
      "properties": ["id"],
      "generated": true
    }
  ]
}
```

Rules:

- support composite keys;
- preserve deterministic key/member order;
- use the emitted JSON Schema property names in `properties` so schema consumers can resolve the references;
- preserve canonical key kind using deterministic lower-case spelling;
- emit `generated` only when semantically relevant/true rather than manufacturing false declarations;
- do not flatten keys to `semanticKey: true` on individual properties;
- do not imply JSON Schema can enforce entity-wide uniqueness.

### `unit`

Preserve canonical scalar `Unit` where the JSON Schema domain node represents that scalar semantic.

Conceptual shape:

```json
"x-stm": {
  "unit": "ms"
}
```

Do not invent unit conversion or validation semantics.

### `ui`

Collect canonical annotations whose key starts with `ui.` and emit them under:

```json
"x-stm": {
  "ui": {
  }
}
```

Mapping:

```text
ui.title       -> x-stm.ui.title
ui.category    -> x-stm.ui.category
ui.order       -> x-stm.ui.order
ui.widget      -> x-stm.ui.widget
ui.customThing -> x-stm.ui.customThing
```

Strip only the leading `ui.` prefix. Do not reinterpret remaining dots into nested objects.

Preserve JSON-compatible values and deterministic key ordering.

Unsupported/non-JSON-compatible values must produce a deterministic JSON Schema diagnostic rather than silent lossy stringification.

### Standard JSON Schema remains native

Do not duplicate these into `x-stm`:

```text
requiredness
nullability
min/max/pattern
numeric constraints
array constraints
format
enum values
oneOf/anyOf/allOf
title
user description
additionalProperties
```

## Focus Area 6 — Update living specifications and terminology before/with implementation

Do not create a new feature-specific specification.

Update the existing living subsystem contracts directly.

At minimum update:

- `docs/specs/core-semantic-vocabulary.md`
- `docs/specs/type-model-dotnet-attributes.md`
- `docs/specs/type-model-ui-hints.md`
- `docs/specs/type-model-compile-time-generator.md`
- `docs/specs/json-schema-domain-model-and-export.md`
- `docs/specs/type-model-projection-capabilities.md`
- `docs/specs/type-model-powerbi-tom-projection.md`
- `docs/TERMINOLOGY.md`

Update `docs/SPECS.md` only if reading-map routing changes.

### Required terminology changes

Add/normalize terms for:

```text
Semantic Mutability
Declared Mutability
Effective Mutability
STM JSON Schema Extension
UI Annotation
```

Remove `Relationship` from lists that define it as a current semantic primitive.

Do not erase ordinary English uses of "relationship" where the word is not naming the removed canonical feature.

### Core vocabulary corrections

Besides deleting the dedicated `Relationship` semantic and relationship annotation keys, remove relationship-shaped wording that makes key/entity/collection semantics depend on the deleted canonical relationship model.

Do not change unrelated semantic definitions.

## Focus Area 7 — Update public API, docs, diagnostics, samples, and package behavior

This milestone deliberately makes breaking public changes.

### Public documentation

Directly update consumer-visible docs made false by M0062.

At minimum inspect/update:

- root `README.md` generator-option summary;
- `public-docs/configuration.md`;
- current core semantics/concepts guide;
- `public-docs/guides/json-schema.md`;
- `public-docs/guides/power-bi.md`;
- `public-docs/guides/projection-capabilities.md`;
- diagnostics reference pages;
- shared NuGet README;
- samples index when sample behavior changes;
- release notes/compatibility documentation for the breaking removal.

Delete the JSON Editor compatibility guide if it no longer describes a supported product capability.

Do not retain an archival copy in the working tree.

### Samples

Update samples that use:

- `SemanticRelationship`;
- relationship inference;
- JSON Editor compatibility options;
- removed UI-hint option types;
- old mutability semantics.

Add or adapt one compact code-first example demonstrating:

- type-level immutable or mutable semantics;
- a property-level override;
- JSON Schema export with `x-stm`;
- technical description preservation;
- UI pass-through metadata.

Do not create a new sample project if an existing sample can demonstrate the behavior coherently.

## Likely Affected Areas

### Canonical/core

- `src/SemanticTypeModel.Abstractions/Model/`
- `src/SemanticTypeModel.Core/`
- core validation, transformation, cloning, query, and inspection
- projection capability catalog

### .NET authoring/generation

- `src/SemanticTypeModel.DotNet/`
- `src/SemanticTypeModel.Generators/`
- generator diagnostics/options
- compile-time semantic manifest only where relationship transport exists

### Projections

- `src/SemanticTypeModel.JsonSchema/`
- `src/SemanticTypeModel.PowerBI/`
- `src/SemanticTypeModel.EFCore/` and `.Generators` only where removed canonical relationship metadata leaks into current code/manifest behavior

### Tests

- Core contract/validation/query/inspection tests
- DotNet extraction tests
- generator tests
- JSON Schema tests
- Power BI tests
- EF/manifest tests when relationship fields are removed from transport
- projection capability tests
- package-smoke consumers

### Documentation/samples

- living specs listed above
- terminology
- public docs/configuration/diagnostics
- JSON Schema and Power BI guides
- shared package README
- relevant samples

## Implementation Constraints

- Prefer removal over compatibility for relationship/editor/old-mutability surfaces explicitly removed by this milestone.
- Do not create deprecated wrappers, aliases, forwarding types, hidden adapters, or obsolete compatibility modes.
- Do not widen `x-stm` beyond the approved initial vocabulary.
- Do not make `x-stm` another canonical model serialization.
- Do not add version negotiation to `x-stm`.
- Keep JSON Schema exporter deterministic.
- Keep runtime and compile-time extraction behavior equivalent.
- Preserve exact-version package-suite policy and manifest alignment established by M0061.
- Do not infer semantic mutability from CLR access shape.
- Do not infer relationships from object shapes or keys after relationship removal.
- Do not remove ownership or key semantics as collateral damage.
- Do not change `Role.ValueObject`/`IsValueObject` representation in M0062.
- Update diagnostics using stable new IDs; never reuse removed IDs.
- Keep changes systematic; avoid unrelated refactors.

## Acceptance Criteria

### Canonical model

- old `Mutability` enum is removed;
- `SemanticMutability` contains only `Mutable` and `Immutable`;
- object-level and property-level mutability declarations are nullable/optional;
- declared and effective semantics remain distinguishable;
- immutable type + mutable property is valid;
- no CLR access shape implicitly creates semantic mutability;
- canonical general relationship types/collections are absent.

### .NET authoring/generation

- `[SemanticMutable]` and `[SemanticImmutable]` work on supported type/member targets;
- conflict diagnostics are deterministic;
- runtime/Roslyn extraction and generated providers agree;
- `SemanticRelationshipAttribute` is absent;
- relationship inference/configuration options are absent;
- generated model/manifest no longer carries removed relationship data.

### JSON Schema

- one `x-stm` object is used;
- `IncludeSemanticAnnotations = true` is the default;
- disabling it produces schema without `x-stm`;
- initial vocabulary is exactly `role`, `aggregateRoot`, `mutability`, `technicalDescription`, `keys`, `unit`, `ui`;
- standard `description` still comes from user description;
- technical description is preserved separately;
- mutability exports declarations, not inherited flattening;
- composite keys are structurally preserved;
- units are preserved without target-specific behavior;
- `ui.*` annotations pass through deterministically;
- unknown JSON-compatible UI keys survive;
- invalid UI annotation values are diagnosed;
- no JSON Editor compatibility mode or editor-specific translation remains.

### Other projections

- no projection consumes removed canonical relationship definitions;
- Power BI does not replace removed relationships with inference;
- EF continues to leave application relationship composition to EF/application configuration;
- projection capability docs/tests no longer claim canonical relationship support.

### Documentation/public surface

- living specs describe implemented M0062 behavior;
- terminology is current;
- configuration docs no longer advertise relationship inference;
- JSON Schema docs describe `x-stm`;
- JSON Editor-specific active documentation is deleted;
- breaking removals are documented for consumers;
- public docs validation succeeds.

### Compatibility

- no compatibility shim exists for removed relationship APIs;
- no compatibility shim exists for removed JSON Editor/UI export APIs;
- no compatibility shim exists for old mixed mutability enum values.

## Validation Plan

M0062 is a capability-provider milestone. Validate implementation capability directly; do not substitute consumer-product validation.

### Tier 0 — edit/static sanity

Run continuously as relevant:

```sh
git diff --check
./eng/public-docs.sh
```

Use repository formatting commands for touched code.

### Tier 1 — focused implementation validation

Use canonical project/focused commands throughout implementation.

At minimum run focused tests for:

```text
SemanticTypeModel.Core.Tests.Unit
SemanticTypeModel.DotNet.Tests.Unit
SemanticTypeModel.Generators.Tests.Unit
SemanticTypeModel.JsonSchema.Tests.Unit
SemanticTypeModel.PowerBI.Tests.Unit
SemanticTypeModel.EFCore.Tests.Unit / EFCore.Generators tests when manifest/relationship transport changes
```

Preferred command form:

```sh
./eng/test-project.sh <affected-test-project>
```

and/or:

```sh
./eng/test-filter.sh <focused-term>
```

Useful focused terms include:

```text
Mutability
Relationship
JsonSchema
UiHint
TechnicalDescription
ProjectionCapability
```

Do not interpret "no remaining Relationship tests" as sufficient removal proof; search active public/source surfaces as well.

### Tier 2 — repository completion gate

Required:

```sh
./eng/check.sh
```

Tier 2 must complete successfully as one aggregate command.

### Tier 3 — provider/package/public validation

Because M0062 changes public contracts and projection/package behavior, require local package validation without publishing.

Use a valid local validation version, for example:

```sh
./eng/package.sh 0.0.0-m0062
./eng/package-smoke.sh 0.0.0-m0062
./eng/public-docs.sh
./eng/samples.sh
```

If repository version policy rejects that validation version, use another non-publishing SemVer accepted by the existing scripts and record it in completion evidence.

`./eng/release-check.sh` is not required by M0062 unless implementation changes release-readiness behavior unexpectedly.

Do not publish.

## Validation Execution Mode

| Validation | Mode |
|---|---|
| Tier 0 | direct |
| Tier 1 | direct |
| Tier 2 `./eng/check.sh` | direct aggregate |
| Tier 3 package/public/sample validation | direct aggregate commands |
| Formal human review | not applicable |

The repository currently does not expose a resumable `--plan-json`/shard/receipt/`--verify` contract for these commands.

M0062 must not add resumable-validation infrastructure merely to satisfy planning format.

## Constrained Runtime Handling

If the execution harness cannot finish Tier 2 or a required Tier 3 aggregate command:

1. continue using Tier 1 focused validation for implementation progress;
2. do not claim aggregate success from child/focused output;
3. run the unchanged canonical aggregate command in CI or another capable execution environment;
4. require the full command's successful final result before completing M0062;
5. record which aggregate command supplied the completion evidence.

Partial output from `./eng/check.sh`, packaging, package smoke, or samples is never aggregate success.

No validation receipt contract is defined for M0062 because the target repository does not currently implement resumable validation for these suites.

## Human Review

### Applicability

`none`

### Rationale

Automated validation can determine whether the approved semantic/public API contract was implemented:

- public API shape is testable;
- extraction/generation equivalence is testable;
- relationship removal is testable;
- JSON Schema output is deterministic and testable;
- UI pass-through behavior is testable;
- documentation consistency has automated checks.

The product/API choices were approved before implementation planning.

### Review infrastructure

- do not create `.review/`;
- do not add review commands;
- no canonical review ID is allocated;
- no `review-check` command applies;
- normal repository/PR code review may still occur, but it is not an M0062 formal completion gate.

If a future milestone introduces output whose acceptability requires human judgment, that future milestone must declare its own milestone-scoped review.

## Direct Documentation Impact

Directly false current authority must be updated during implementation, not deferred.

This includes at minimum:

- core semantic vocabulary;
- .NET attribute contract;
- UI annotation contract;
- compile-time generator options where relationship inference is described;
- JSON Schema domain/export contract;
- projection capability contract;
- Power BI contract where canonical relationships are consumed;
- terminology;
- consumer configuration;
- JSON Schema public guide;
- Power BI/projection capability public docs;
- diagnostics;
- package README;
- compatibility/release notes.

The working tree carries current truth. Delete obsolete JSON Editor compatibility documentation rather than archiving it.

## Deferred Documentation Synchronization

Residual normalization is tracked in:

- `.guide-sync/pending/m0062-semantic-vocabulary-and-json-schema-extensions.md`

The implementation agent is **not required to read that file**.

Before completing M0062, directly update all documentation made false by implementation. The later documentation-sync pass is only for residual wording/reference cleanup.

## Out-of-Scope Guide Migration Work

None.

The repository already records guide-system v0.6.0 and the M0061 engineering-command migration is complete.

Do not modify:

- `.guide-profile.json`;
- guide-system metadata;
- TBPs;
- issue templates;
- copied setup/engineering guides;
- engineering command architecture unless a direct M0062 defect requires it.

## Completion Checklist

M0062 may complete only when all of the following are true:

- [ ] lifecycle mutability contract implemented and tested;
- [ ] type/property authoring attributes implemented and tested;
- [ ] old CLR/access mutability values removed;
- [ ] general canonical relationships removed without compatibility;
- [ ] relationship inference/authoring/options removed;
- [ ] relationship fallout removed from projections/manifests/capabilities;
- [ ] JSON Editor-specific export/UI mode removed;
- [ ] open `ui.*` pass-through contract implemented;
- [ ] `x-stm` implemented with exactly the approved initial vocabulary;
- [ ] technical descriptions preserved under `x-stm.technicalDescription`;
- [ ] living specs/terminology updated;
- [ ] public docs/configuration/diagnostics updated;
- [ ] obsolete JSON Editor active docs deleted;
- [ ] Tier 1 focused validation passes;
- [ ] Tier 2 `./eng/check.sh` passes completely;
- [ ] required Tier 3 package smoke/public docs/samples validation passes completely;
- [ ] no formal human-review gate is pending;
- [ ] no release was published;
- [ ] residual documentation-sync work is either completed or accurately queued;
- [ ] durable outcomes are synchronized before this milestone file is deleted;
- [ ] `docs/MILESTONES.md` returns to no-active-milestone state with M0063 next.
