# Execute M0059 — CLR-to-Provider EF Regression Contract and 2.6.1 Preparation

Implement milestone:

```text
docs/milestones/m0059-ef-clr-to-provider-regression-and-2-6-1.md
```

Repository:

```text
carlrabbit/dotnet-semantic-type-model
```

## Operating Mode

Execute the milestone directly.

Do not redesign the EF integration broadly. Do not publish packages. Do not ask for approval between ordinary implementation steps.

Use repository authority and canonical `eng/` commands.

## Required Sequence

1. Read `AGENTS.md`, the command contract, M0059, and only the directly referenced EF specs/decisions.
2. Inspect the current EF projection/application implementation and the M0056–M0058 fixtures/tests.
3. Add a compiled real CLR fixture and real `DbContext` that reproduces the reported enum failure.
4. Ensure the regression path obtains the semantic model from the actual CLR extraction/provider path; do not construct it manually.
5. Demonstrate the pre-fix failure and record the exact exception or invalid metadata.
6. Identify the precise EF convention/application-order root cause.
7. Add finalized-model metadata assertions.
8. Apply the narrow production fix.
9. Add SQLite model-finalization, `EnsureCreated`, insert, and reload coverage.
10. Prove the test detects deliberate removal of enum conversion and non-entity suppression through test structure or targeted assertions.
11. Update directly affected specs/decisions only where durable truth changed.
12. Prepare version and release artifacts for `2.6.1`.
13. Run focused, standard, and release validation.
14. Stop before publication.
15. Complete the milestone's completion notes with concrete evidence.

## Hard Requirements

The canonical regression must execute:

```text
compiled CLR model
→ actual semantic extraction/provider
→ actual DbContext.OnModelCreating
→ semantic EF application
→ provider-backed model finalization
→ final metadata audit
→ SQLite EnsureCreated
→ save
→ reload
```

The regression is invalid if it starts from a manually constructed `TypeSchemaModel`.

The final audit must cover more than entity inventory. It must detect unexpected:

```text
navigations
skip navigations
foreign keys
shadow FK properties
implicit join entities
owned EF types
keyless types
```

Approved TPT metadata must be handled explicitly.

## Scope Control

Do not add:

```text
relationship/navigation support
new conditional operators
database conditional constraints
legacy compatibility modes
consumer switches that disable scanning
unrelated 2.6 features
```

Do not publish `2.6.1`.

## Validation

Run the repository equivalents of:

```sh
./eng/test-filter.sh M0059
./eng/test-project.sh tests/unit/SemanticTypeModel.EFCore.Tests.Unit
./eng/test-project.sh tests/integration/SemanticTypeModel.EFCore.Tests.Integration
./eng/check.sh
./eng/package.sh 2.6.1
./eng/package-smoke.sh 2.6.1
./eng/samples.sh
./eng/public-docs.sh
./eng/release-check.sh 2.6.1
```

Inspect:

```sh
find artifacts/nuget -maxdepth 1 -type f -print | sort
```

## Final Report

Report:

```text
pre-fix reproduction
exact root cause
production correction
compiled fixture path
final EF metadata invariant
tests added
focused validation
repository validation
release validation
package inventory
public API result
documentation changes
remaining risks
publication status
```

Be explicit about any command not run or any failure. Do not claim release readiness without the Tier 4 validation results.
