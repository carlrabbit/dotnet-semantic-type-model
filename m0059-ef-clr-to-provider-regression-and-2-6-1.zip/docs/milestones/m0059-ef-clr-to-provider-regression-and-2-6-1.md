# M0059 — CLR-to-Provider EF Regression Contract and 2.6.1 Release Preparation

## Status

Planned.

## Goal

Correct the EF Core enum/model-discovery defect that remains reproducible after `2.6.0`.

Establish a permanent end-to-end EF regression contract that starts with compiled, scannable CLR model classes and ends with a finalized provider-backed EF model and database round-trip.

Prepare, but do not publish, release `2.6.1`.

The milestone closes the test-boundary gap exposed by the defect:

```text
semantic-model tests prove semantic derivation
ModelBuilder tests prove partial EF application
real DbContext tests prove EF convention interaction
provider-backed tests prove model finalization and persistence
```

A release is not considered validated when the EF tests begin from a hand-constructed `TypeSchemaModel` and therefore bypass the CLR shapes that EF scans.

## Repository Profile

| Field | Value |
|---|---|
| Repository | `carlrabbit/dotnet-semantic-type-model` |
| Profile | `dotnet-library` |
| Role | Product repository and capability provider |
| Released baseline | `2.6.0` |
| Target release | `2.6.1` |
| Milestone type | Defect correction, regression hardening, and patch-release preparation |
| Execution mode | `ai-executed-human-reviewed` |
| Publication | Separate human-approved follow-up |

## Problem Statement

The enum-related EF error persists after `2.6.0`.

The current test structure over-represents tests that construct or consume a semantic model directly. Those tests validate one aspect of the integration but cannot reproduce failures caused by EF Core inspecting real CLR types.

A test beginning here:

```text
constructed TypeSchemaModel
→ EfRelationalModel derivation
→ ModelBuilder application
```

bypasses behavior originating here:

```text
compiled CLR model
→ DbSet roots
→ CLR property and collection discovery
→ relationship/navigation conventions
→ semantic extraction
→ semantic relational application
→ model finalization
```

Consequently, the following defect classes can remain undetected:

```text
enum CLR type treated incorrectly during property discovery
ValueKind CLR type discovered as an EF entity
reference property discovered as a navigation before conversion
collection property discovered as a relationship
shadow foreign key introduced by convention
unexpected keyless entity
converter applied after convention metadata already leaked
inherited CLR member configured on the wrong entity
provider finalization rejecting a model that standalone derivation accepted
```

The correction must address both the concrete enum defect and the missing permanent test boundary.

## Design Principle

For EF Core integration, the authoritative regression test is the complete executable composition:

```text
real compiled model classes
→ actual semantic extraction/provider
→ actual DbContext.OnModelCreating
→ ApplySemanticTypeModel
→ EF model finalization
→ provider schema creation
→ insert
→ reload
```

Smaller tests remain valuable, but they do not replace this path.

## Required Authority

Read only the authority needed for this milestone:

- `AGENTS.md`
- `docs/ENGINEERING.md`
- `docs/engineering/command-contract.md`
- `docs/specs/opinionated-ef-relational-projection-contract.md`
- `docs/specs/ef-model-shape-test-matrix-and-member-placement.md`
- `docs/specs/typed-literals-and-conditional-constraint-semantics.md`
- `docs/decisions/ef-convention-discovered-non-entities-are-suppressed.md`, or its current equivalent
- `docs/milestones/m0056-*`
- `docs/milestones/m0057-*`
- `docs/milestones/m0058-*`
- directly affected EF source, fixture, and test files

Do not treat external project or engineering guides as repository authority.

## Scope

This milestone includes:

```text
reproduce the current enum failure with real compiled CLR classes
identify the exact EF convention or application-order cause
correct the EF projection/application implementation
introduce permanent CLR-to-provider test fixtures
validate exact final EF metadata, not only semantic projection output
run provider-backed SQLite model creation and persistence tests
prepare package and documentation changes for 2.6.1
```

## Non-Goals

```text
new semantic literal kinds
new conditional operators
database enforcement of SemanticRequiredWhen
relationship/navigation support
owned EF entity mappings
TPH or TPC support
provider-specific JSON querying
broad EF architecture redesign
publishing 2.6.1
```

## Focus Areas

### Focus Area A — Capture the Exact Failure as a Real CLR Fixture

#### Goal

Create the smallest compiled model that reproduces the reported enum error without constructing the semantic model manually.

#### Scope

Add a dedicated fixture model containing at minimum:

```text
ImportSpecification entity
ImportType enum
CsvSourceSpecification ValueKind
XmlSourceSpecification ValueKind
WebService1SourceSpecification ValueKind
WebService2SourceSpecification ValueKind
SemanticRequiredWhen conditions using nameof(ImportType.Member)
SemanticOwned object declarations for the source specifications
```

The fixture must use the same public attributes and provider/extraction path used by consumers.

Prefer extending the existing focused EF model-shape fixture project when it can remain small and explicit. Otherwise add a dedicated compiled fixture project.

The fixture must include a real test `DbContext` with actual `DbSet<TEntity>` roots.

#### Non-Goals

- Building an equivalent `TypeSchemaModel` by hand.
- Testing only the literal normalizer.
- Testing only `DeriveEfRelationalModel`.
- Replacing the failing shape with a simplified shape that no longer triggers EF scanning.

#### Likely Files

- `tests/fixtures/SemanticTypeModel.EFCoreModelShapes/`
- `tests/fixtures/SemanticTypeModel.RealWorldFixtures/`
- `tests/unit/SemanticTypeModel.EFCore.Tests.Unit/`
- `tests/integration/SemanticTypeModel.EFCore.Tests.Integration/`

#### Validation Tier

Tier 1 during fixture development.

#### Direct Documentation Impact

- Add fixture intent to the relevant EF test specification when the current specification does not already require compiled CLR fixtures.

#### Deferred Documentation Impact

- Public EF guide examples, unless public behavior changes.

#### Acceptance Criteria

- The pre-fix test fails with the same exception or the same invalid EF metadata condition as the consumer report.
- The test obtains the semantic model through the real CLR extraction/provider path.
- The test creates the EF model through a real `DbContext`.
- No manually assembled semantic model is used in the regression path.
- The fixture remains small enough that every scannable CLR type is intentional and reviewable.

### Focus Area B — Diagnose and Correct the Enum/Convention Interaction

#### Goal

Fix the concrete defect rather than weakening or bypassing the regression test.

#### Scope

Trace the complete model-building order:

```text
EF convention discovery
semantic Entity allowlist construction
non-entity suppression
entity registration
property configuration
enum converter configuration
JSON converter configuration
post-configuration cleanup
EF model finalization
```

Determine whether the remaining error is caused by one or more of:

```text
enum type incorrectly entering object/entity extraction
ValueKind property retained as navigation metadata
Ignore/cleanup applied before a later convention reintroduces metadata
property configuration occurring on the wrong declaring/storage type
converter configuration occurring after relationship discovery
nullable enum provider mapping mismatch
conditional metadata affecting member classification
final audit checking entity inventory but not leaked relationship metadata
```

Implement the narrowest correction consistent with the existing opinionated EF contract.

#### Non-Goals

- Adding a consumer option to disable EF scanning.
- Reintroducing legacy modes or compatibility aliases.
- Suppressing arbitrary EF errors without identifying their metadata source.
- Ignoring the affected property instead of mapping it.

#### Likely Files

- `src/SemanticTypeModel.EFCore/EfRelationalProjection.cs`
- `src/SemanticTypeModel.EFCore/EfRelationalModel.cs`
- directly related diagnostics and helper files
- focused unit and integration tests

#### Validation Tier

Tier 1, followed by Tier 2 after the fix stabilizes.

#### Direct Documentation Impact

- Update the EF projection contract only if the durable invariant or application order changes.
- Add or revise a decision only if the implementation requires a new durable choice.

#### Deferred Documentation Impact

- Broad public-document synchronization.

#### Acceptance Criteria

- The exact pre-fix regression test passes.
- `ImportType` remains an enum scalar and is mapped using the approved string representation.
- Nullable enum variants remain nullable scalar columns.
- `SemanticRequiredWhen` metadata does not alter EF entity or relationship discovery.
- Each source `ValueKind` remains a converted JSON property.
- No source `ValueKind` becomes an EF entity, owned EF entity, navigation target, or keyless type.
- No exception is hidden by removing the affected property from the model.

### Focus Area C — Final EF Metadata Contract

#### Goal

Detect convention leakage that an entity-inventory assertion alone cannot detect.

#### Scope

Add reusable assertions over the finalized provider-backed `IModel`.

The audit must compare the finalized model to an explicit allowlist derived from the semantic relational projection.

At minimum audit:

```text
entity CLR type inventory
table mapping
inheritance strategy
keys
scalar properties
JSON-converted properties
binary properties
provider CLR types
value converters
nullability
navigations
skip navigations
foreign keys
shadow properties
unexpected indexes
owned metadata
keyless metadata
```

Approved TPT implementation metadata must be handled explicitly rather than accidentally rejected.

The audit should distinguish:

```text
approved EF infrastructure metadata
unexpected domain relationship metadata
```

#### Non-Goals

- Snapshotting every unstable provider annotation.
- Asserting EF internal implementation details with no contract value.
- Banning approved TPT base linkage.

#### Likely Files

- `tests/unit/SemanticTypeModel.EFCore.Tests.Unit/`
- `tests/integration/SemanticTypeModel.EFCore.Tests.Integration/`
- shared EF test assertion helpers

#### Validation Tier

Tier 1.

#### Direct Documentation Impact

- Update the EF model-shape test specification with the finalized-model audit boundary.

#### Deferred Documentation Impact

- None.

#### Acceptance Criteria

- Final EF entity CLR types exactly equal the semantic Entity CLR type allowlist.
- `FindEntityType` returns `null` for all semantic `ValueKind` CLR types.
- The entity property for each JSON `ValueKind` still exists and has the expected converter/comparer.
- No unexpected domain navigation or skip navigation exists.
- No unexpected domain foreign key or shadow FK property exists.
- No implicit join entity exists.
- No unexpected keyless type exists.
- TPT metadata is checked against an explicit approved shape.
- Failure messages identify the leaked metadata and CLR type.

### Focus Area D — Provider-Backed End-to-End Regression Matrix

#### Goal

Prove the corrected behavior through EF model finalization and persistence.

#### Scope

Add SQLite in-memory integration tests that:

```text
construct DbContextOptions with the SQLite provider
instantiate the real fixture DbContext
force context.Model finalization
call EnsureCreated
insert a fixture entity
save changes
clear tracking or create a new context
reload the entity
verify enum and JSON values
```

Include at least:

```text
non-null enum with one conditional JSON object
different enum member with another conditional JSON object
nullable enum variant where applicable
null JSON properties
multiple JSON source properties present in CLR shape
TPT entity inheritance if part of the fixture
```

Conditional semantics are metadata only for EF; the test does not require EF to enforce them.

#### Non-Goals

- SQL Server-specific JSON query testing.
- Database CHECK constraints for conditions.
- Full application workflow testing.

#### Likely Files

- `tests/integration/SemanticTypeModel.EFCore.Tests.Integration/M0059ClrToProviderRegressionTests.cs`
- fixture project files
- test project references

#### Validation Tier

Tier 1 during implementation; Tier 3 in PR validation.

#### Direct Documentation Impact

- None beyond the test-matrix specification.

#### Deferred Documentation Impact

- Public examples only when useful.

#### Acceptance Criteria

- SQLite model finalization succeeds.
- `EnsureCreated` succeeds.
- Insert and reload succeed.
- Enum values round-trip through their approved provider representation.
- JSON `ValueKind` objects round-trip.
- Finalized-model metadata assertions run against the same context.
- The integration tests fail when the enum converter or non-entity suppression is deliberately removed.

### Focus Area E — Test-Layer Policy and Regression Placement

#### Goal

Prevent future EF fixes from being validated only through semantic-model construction.

#### Scope

Document and enforce the test-layer distinction:

| Layer | Purpose | May construct semantic model manually? |
|---|---|---|
| Core semantic unit | Canonical validation and derivation | Yes |
| .NET extraction unit | CLR/Roslyn extraction | No for extraction behavior |
| EF relational unit | Relational derivation rules | Yes |
| EF CLR application | Convention interaction with compiled model | No |
| EF provider integration | Finalization, schema, persistence | No |

For every defect involving EF discovery, lookup, model finalization, provider mapping, navigation inference, converter application, or real CLR member placement, require at least one real compiled CLR fixture test.

Add a lightweight repository check or test naming convention only if it is simple and durable. Do not add process machinery solely for this milestone.

#### Non-Goals

- Forcing every EF unit test to use a real database.
- Removing useful manually constructed semantic-model tests.
- Duplicating every assertion at every layer.

#### Likely Files

- `docs/specs/ef-model-shape-test-matrix-and-member-placement.md`
- `docs/ENGINEERING.md` only if a repository-specific command or validation rule changes
- test project documentation comments where useful

#### Validation Tier

Tier 0 for documentation; Tier 1 for any enforcement test.

#### Direct Documentation Impact

- Update the authoritative EF test-matrix specification.

#### Deferred Documentation Impact

- None.

#### Acceptance Criteria

- The specification states that semantic-model-only tests cannot close EF convention/provider defects.
- The specification identifies which EF defect classes require compiled CLR fixtures and provider-backed tests.
- The M0059 regression is referenced as the canonical example.
- Existing lower-layer tests remain focused rather than being replaced wholesale.

### Focus Area F — 2.6.1 Release Preparation

#### Goal

Prepare a complete, reviewable, non-publishing patch release.

#### Scope

Update all directly affected release artifacts to `2.6.1`.

Required release work:

```text
package version metadata
release notes
public EF projection documentation when behavior or guarantees changed
package README/version examples where current release is stated
sample package references when required
public API baseline only if the public API changed
package smoke consumer
milestone and index status
```

The release note must state:

```text
fixed remaining EF enum/model-discovery failure
added compiled-CLR-to-provider regression coverage
added finalized EF metadata leakage checks
no new EF relationship feature was introduced
```

Do not describe a test-only change if production code changed. Describe the actual consumer-visible correction.

#### Non-Goals

- Publishing packages.
- Adding unrelated features to the patch.
- Bundling deferred documentation redesign.
- Changing the 2.6 semantic literal contract unless required by the reproduced defect.

#### Likely Files

- `Directory.Build.props`, `Directory.Packages.props`, or current version authority
- `public-docs/release-notes.md`
- package README sources
- sample project package references
- `docs/MILESTONES.md`
- `docs/milestones/m0059-*`
- `.guide-sync/pending/` only when repository convention requires a follow-up marker

#### Validation Tier

Tier 4.

#### Direct Documentation Impact

- Release notes.
- Current-version references.
- EF guide correction if the supported behavior statement changes.

#### Deferred Documentation Impact

- Broad documentation synchronization not required for release correctness.

#### Acceptance Criteria

- Version authority is set to `2.6.1`.
- Release notes identify the concrete fix and regression coverage.
- Package smoke tests consume the generated `2.6.1` packages.
- Samples build against the prepared version where repository release policy requires it.
- No unintended public API change exists.
- Package contents contain no stale `2.6.0` current-version metadata except historical release notes.
- No package is published by this milestone.

## Required Regression Fixture Shape

Use a compiled fixture structurally equivalent to:

```csharp
public enum ImportType
{
    CsvFile,
    XmlFile,
    WebService1,
    WebService2
}

[SemanticEntity]
public sealed class ImportSpecification
{
    public required ImportSpecificationId Id { get; init; }

    public ImportType ImportType { get; init; }

    [SemanticOwned(Kind = SemanticOwnershipKind.Object)]
    [SemanticRequiredWhen(nameof(ImportType), nameof(ImportType.CsvFile))]
    public CsvSourceSpecification? CsvSource { get; init; }

    [SemanticOwned(Kind = SemanticOwnershipKind.Object)]
    [SemanticRequiredWhen(nameof(ImportType), nameof(ImportType.XmlFile))]
    public XmlSourceSpecification? XmlSource { get; init; }

    [SemanticOwned(Kind = SemanticOwnershipKind.Object)]
    [SemanticRequiredWhen(nameof(ImportType), nameof(ImportType.WebService1))]
    public WebService1SourceSpecification? WebService1Source { get; init; }

    [SemanticOwned(Kind = SemanticOwnershipKind.Object)]
    [SemanticRequiredWhen(nameof(ImportType), nameof(ImportType.WebService2))]
    public WebService2SourceSpecification? WebService2Source { get; init; }
}
```

Use the repository's actual attribute names, type declarations, strong identifier shape, and source-provider mechanism. The snippet defines required structure, not exact source text.

## Required End-to-End Test Path

The canonical regression test must execute:

```text
compiled fixture assembly
→ semantic provider/extractor
→ canonical TypeSchemaModel
→ DeriveEfRelationalModel
→ real fixture DbContext.OnModelCreating
→ ApplySemanticTypeModel
→ context.Model finalization
→ metadata contract audit
→ SQLite EnsureCreated
→ insert/save
→ reload/assert
```

The test must not replace any step with a manually constructed equivalent.

## Required Assertions

### Semantic Layer

- `ImportType` is an enum scalar.
- Each conditional comparison literal is an enum-member literal.
- Each literal retains the enum type/member identity required by the 2.6 contract.
- Source `ValueKind` types are structural types, not semantic entities.

### Relational Projection

- `ImportType` is a scalar column with the approved string provider representation.
- Each source property is a JSON column.
- Column declaring/storage metadata points to the correct CLR entity.
- No source `ValueKind` is projected as an entity.

### Final EF Model

- Final entity CLR inventory exactly matches semantic Entity CLR inventory.
- `ImportType` is an EF scalar property with the expected converter.
- Each source property is an EF property with the expected JSON converter and comparer.
- Every source `ValueKind` returns `null` from `FindEntityType`.
- No unexpected domain navigation, foreign key, skip navigation, shadow FK, implicit join entity, owned entity, or keyless entity exists.
- TPT metadata matches the approved hierarchy where inheritance is present.

### Provider Execution

- Model finalization succeeds.
- SQLite `EnsureCreated` succeeds.
- Save succeeds.
- Reload succeeds.
- Enum values round-trip.
- JSON object values round-trip.

## Diagnostics

Do not introduce a new diagnostic merely because EF throws an exception.

Add a diagnostic only when the library can detect and explain a stable invalid semantic/relational condition before EF finalization.

When residual convention metadata remains after application, prefer an existing diagnostic where semantically accurate. Add a new stable diagnostic only when the existing contract cannot identify the leaked metadata category.

Any new diagnostic must include:

```text
stable code
affected semantic type/property
affected CLR type/member
unexpected EF metadata category
actionable remediation or library defect classification
```

## Integration Notes

Implementation order:

1. Add the compiled failing fixture and real `DbContext`.
2. Confirm the regression test fails before changing production code.
3. Capture the exact EF exception and finalized/intermediate metadata involved.
4. Add focused metadata assertions that expose the cause.
5. Apply the narrow production fix.
6. Run the complete fixture path.
7. Generalize the metadata audit without coupling to unstable EF internals.
8. Run focused unit and integration suites.
9. Run standard repository validation.
10. Prepare `2.6.1` release artifacts.
11. Run full release validation.
12. Stop before publication.

Do not begin with version bumps or release-note edits before the failing test exists.

## Validation Commands

Use repository commands. Adjust only when current command contracts differ.

### Focused Implementation Validation

```sh
./eng/test-filter.sh M0059
./eng/test-filter.sh ClrToProvider
./eng/test-filter.sh Enum
./eng/test-filter.sh Convention
./eng/test-filter.sh ModelShape

./eng/test-project.sh tests/unit/SemanticTypeModel.EFCore.Tests.Unit
./eng/test-project.sh tests/integration/SemanticTypeModel.EFCore.Tests.Integration
```

### Standard Local Validation

```sh
./eng/check.sh
```

### 2.6.1 Release Validation

```sh
./eng/package.sh 2.6.1
./eng/package-smoke.sh 2.6.1
./eng/samples.sh
./eng/public-docs.sh
./eng/release-check.sh 2.6.1
```

Inspect generated packages:

```sh
find artifacts/nuget -maxdepth 1 -type f -print | sort
```

Do not publish packages.

## Acceptance Criteria

### Defect

- The current enum-related EF failure is reproduced before the fix using compiled real model classes.
- The root cause is documented in the completion notes.
- The production correction fixes the actual EF metadata/application-order issue.
- The correction does not remove or ignore the affected enum or JSON properties.

### Test Boundary

- A permanent compiled CLR fixture covers the exact reported shape.
- A real `DbContext` with `DbSet` roots executes the semantic application.
- A provider-backed finalized `IModel` is audited.
- SQLite schema creation and persistence are exercised.
- Semantic-model-only tests are retained for lower-layer behavior but are not treated as sufficient regression coverage.

### Metadata Contract

- Entity inventory is exact.
- Enum scalar mapping is exact.
- JSON `ValueKind` mappings are exact.
- Unexpected EF relationship, ownership, shadow, keyless, and join metadata is absent.
- Approved TPT metadata is explicitly accounted for.

### Regression Strength

- The test fails if enum conversion is removed.
- The test fails if a source `ValueKind` is convention-discovered as an entity.
- The test fails if a source property remains a navigation instead of a converted property.
- The test fails if provider model finalization rejects the model.
- Failure output identifies the relevant CLR type/member and metadata mismatch.

### Release

- Directly affected docs and release metadata target `2.6.1`.
- `./eng/check.sh` passes.
- `./eng/package.sh 2.6.1` passes.
- `./eng/package-smoke.sh 2.6.1` passes.
- `./eng/samples.sh` passes.
- `./eng/public-docs.sh` passes.
- `./eng/release-check.sh 2.6.1` passes.
- Generated package inventory is reviewed.
- No package is published inside the milestone.

## Human Review Requirements

Human review is required for:

```text
fidelity of the compiled fixture to the consumer model
captured pre-fix exception and root-cause explanation
production fix scope
final EF metadata allowlist
TPT metadata exceptions
test sensitivity to deliberate regressions
public API diff
2.6.1 release notes
generated package inventory
publication approval
```

## Completion Notes

Complete after implementation with:

```text
exact reproduced exception
root cause
production files changed
fixture/test files added
final metadata invariant
focused validation results
repository validation result
release validation result
package inventory
public API result
known residual risks
human publication decision
```
