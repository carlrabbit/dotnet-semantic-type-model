# M0063 — Documentation Sync and 4.0.0 Release Readiness

## Goal

Finish documentation synchronization against the implemented post-M0062 repository, prepare and validate the
SemanticTypeModel **4.0.0** release candidate, and stop before publication.

This overlay intentionally contains several release-facing documentation replacements so the implementation
agent starts from synchronized product truth rather than reconstructing the M0061/M0062 planning discussion.

## Repository Assumptions

| Dimension | Value |
|---|---|
| Repository | `carlrabbit/dotnet-semantic-type-model` |
| Profile | `base` + `dotnet-library` |
| Repository role | capability-provider |
| Maturity | published-maintenance |
| Guide-system metadata | v0.6.0 |
| Execution mode | documentation-sync + release-readiness |
| Release candidate | 4.0.0 |
| Formal human review | none |
| Publication | excluded |

## Execution Mode

Run the milestone in this order:

```text
apply overlay
  -> verify overlay text against current implementation
  -> complete remaining documentation sync
  -> validate docs
  -> prepare 4.0.0 artifacts
  -> run full release-check
  -> inspect release evidence
  -> complete milestone
```

Automated release validation is the completion gate. There is no `.review/` request, record, or review-check
step in M0063.

## Scope

### Already synchronized by this overlay

Review and correct only if implementation differs:

- root README semantic/release boundaries;
- public generator configuration, including removal of relationship inference;
- public core semantics, mutability, description, UI, and relationship boundaries;
- projection capability matrix;
- Power BI relationship-removal guidance;
- compatibility and 4.0.0 migration boundary;
- shared NuGet package-suite guidance;
- active milestone routing.

### Remaining synchronization work

Inspect and update all remaining active surfaces, especially:

- `docs/TERMINOLOGY.md` — remove `relationship` from the current `Semantic Primitive` list while preserving
  ordinary non-feature uses of the word;
- authoritative specs not already correct;
- diagnostics reference pages;
- `public-docs/usage.md`;
- `public-docs/guides/ef-core.md`;
- `public-docs/guides/configuration-options.md`;
- `public-docs/guides/system-text-json.md` where cross-links/boundaries are stale;
- `public-docs/samples.md`;
- `public-docs/versioning.md` if release-candidate wording needs clarification;
- `public-docs/release-notes.md`;
- package/sample documentation discovered by `./eng/public-docs.sh`.

Do not rewrite documents that already state current truth merely to mention M0063.

## Required Authority

Read:

- `AGENTS.md`
- `README.md`
- `docs/TERMINOLOGY.md`
- `docs/SPECS.md`
- relevant current specs only
- `docs/ARCHITECTURE.md` and directly relevant architecture
- `docs/DECISIONS.md` and current decisions relevant to changed surfaces
- `docs/ENGINEERING.md`
- `docs/engineering/command-contract.md`
- `docs/engineering/packaging.md`
- `docs/engineering/release-readiness.md`
- `docs/engineering/public-documentation.md`
- `docs/engineering/package-documentation.md`
- `docs/engineering/samples.md`
- `docs/PUBLIC-DOCS.md`
- `docs/WORKFLOWS.md`
- `.github/workflows/release-check.yml`
- `.github/workflows/pack.yml`
- `.github/workflows/publish-nuget.yml`
- `public-docs/versioning.md`
- `public-docs/api/compatibility.md`
- `public-docs/release-notes.md`
- `public-docs/nuget/SemanticTypeModel.md`
- `docs/MILESTONES.md`

Do not read the external guide repository during implementation. Ordinary implementation work does not need
`.guide-profile.json` or `.guide-sync/`.

## Documentation Truth to Enforce

### Canonical semantics

- lifecycle mutability is optional;
- values are `Mutable` and `Immutable` only;
- property declaration overrides type declaration;
- mutable property inside immutable type is valid;
- CLR access shape does not infer lifecycle mutability;
- general canonical relationship semantics are removed;
- structural object references/collections, keys, ownership, aggregate roots, and envelopes remain distinct.

### JSON Schema

- code-first canonical STM -> JSON Schema domain model -> Draft 2020-12;
- no JSON Schema import authoring path;
- optional semantic annotations use one `x-stm` object;
- initial vocabulary is exactly `role`, `aggregateRoot`, `mutability`, `technicalDescription`, `keys`, `unit`, `ui`;
- standard `description` uses `UserDescription`;
- technical text remains separate;
- `ui.*` is open pass-through metadata;
- no JSON Editor compatibility mode or widget-inference system.

### EF Core

- generated `IEntityTypeConfiguration<TEntity>` application is the supported application path;
- explicit model selection;
- model assembly manifest is ephemeral internal build transport;
- producer/consumer STM suite versions must match exactly;
- generated config owns only selected semantic entities;
- application owns `DbContext`, unrelated/manual entities, and target-specific relationships;
- do not restore runtime global `ModelBuilder` application or relationship inference.

### Package topology

- no `SemanticTypeModel.Configuration.Generators`;
- JSON Schema import is removed;
- every STM package/analyzer used together must use the same exact version;
- package inventory must be derived from current packable projects/engineering inventory.

## 4.0.0 Release Notes

Rewrite the top of `public-docs/release-notes.md` into one coherent **4.0.0 release candidate** section.

The 4.0.0 entry must consolidate the currently unreleased M0062 and unpublished 3.0.0 candidate into the current
consumer-facing release boundary unless verified publication truth proves they were independently published.

Cover at minimum:

- EF generated-configuration architecture;
- explicit model selection and application-owned composition;
- exact-version semantic manifest;
- Configuration.Generators removal;
- JSON Schema import removal;
- optional lifecycle mutability;
- relationship model/attribute/inference removal;
- JSON Schema `x-stm`;
- technical-description preservation;
- open `ui.*`;
- JSON Editor compatibility removal;
- concise migration steps;
- package-suite exact-version requirement;
- status: release candidate / not published.

Preserve historical release-note content below the new 4.0.0 entry. Do not delete historical chronology just to
simplify the file.

### Publication truth

Before claiming an exact "previous published version", verify the actual package/release channel.

If that cannot be verified, do not guess. 4.0.0 migration guidance can describe removed/current APIs without
naming an unverified previous-published baseline.

## Non-Goals

- product implementation work unless documentation exposes a concrete defect that blocks truthful release docs;
- compatibility shims;
- relationship replacement;
- `x-stm` expansion;
- engineering-command redesign;
- formal review infrastructure;
- resumable-validation infrastructure;
- NuGet publication;
- tag creation;
- GitHub Release creation.

## Validation

### Documentation/static

```sh
git diff --check
./eng/public-docs.sh
```

### Focused behavior verification

Use only as needed to validate a documentation claim:

```sh
./eng/test-project.sh <project>
./eng/test-filter.sh <term>
./eng/check-affected.sh <paths...>
```

### Repository gate

```sh
./eng/check.sh
```

### Release candidate diagnostics

These may be run individually while fixing failures:

```sh
./eng/package.sh 4.0.0
./eng/package-smoke.sh 4.0.0
./eng/samples.sh
./eng/public-docs.sh
```

### Final release-readiness gate

Required:

```sh
./eng/release-check.sh 4.0.0
```

If constrained local execution cannot finish it, use the existing GitHub `release-check` workflow with
`version=4.0.0`.

Partial child/focused output is never aggregate release success.

## Package Evidence

After the release check, inspect `artifacts/nuget/` and verify:

- expected package IDs only;
- all suite packages are exactly `4.0.0`;
- no `SemanticTypeModel.Configuration.Generators`;
- expected analyzer assets;
- aligned STM package dependencies;
- shared package README;
- no unintended source/repository artifacts.

No generated package needs to be committed.

## Human Review

Applicability: **none**.

M0063 has no `.review/` state and no milestone-scoped approval gate. Automated release readiness determines
milestone completion.

This does not publish the release. Publication remains a separate explicit operation requested after M0063.

## Constrained Execution

The repository does not currently expose resumable `--plan-json`/receipt/verify semantics for release-check.

Do not invent them.

If the local aggregate cannot complete:

1. use child commands only for diagnosis;
2. run the existing CI `release-check` workflow for `4.0.0`;
3. require its complete successful result;
4. record the run identity in the completion summary.

## Acceptance Criteria

- overlay documentation is verified against actual implementation;
- remaining stale current documentation is synchronized;
- `relationship` is not documented as a current canonical primitive/API;
- mutability docs consistently use optional lifecycle semantics;
- JSON Schema docs consistently describe current `x-stm`;
- JSON Editor compatibility is absent from current supported guidance;
- Power BI does not claim canonical relationship projection;
- EF docs use generated configuration and exact suite-version manifest alignment;
- Configuration.Generators and JSON Schema import are absent from current package/usage guidance;
- 4.0.0 release notes are coherent and preserve historical chronology;
- compatibility/migration guidance is actionable;
- publication truth is not guessed;
- `./eng/public-docs.sh` passes;
- `./eng/check.sh` passes;
- complete `./eng/release-check.sh 4.0.0` or equivalent CI workflow passes;
- package contents/inventory are inspected;
- no publish, tag, or GitHub Release operation occurred.

## Completion

After acceptance criteria pass:

- delete this completed milestone according to repository lifecycle;
- restore `docs/MILESTONES.md` to no active milestone;
- leave `M0064` as the next milestone number.

## Publication Boundary

M0063 explicitly excludes:

```sh
./eng/publish.sh 4.0.0
```

Do not trigger `publish-nuget.yml`, publish to NuGet, create a tag, or create a GitHub Release.

Those require a separate explicit user instruction.
