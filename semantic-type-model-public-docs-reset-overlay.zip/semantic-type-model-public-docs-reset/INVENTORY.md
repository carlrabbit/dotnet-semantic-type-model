# Overlay Inventory

## Baseline

`6a1540eef88eb2fecb984fb90842c01a716ca5d0`

## Structural result

The intended public-documentation surface is:

```text
README.md
CONTRIBUTING.md
AGENTS.md

public-docs/
  usage.md
  configuration.md
  troubleshooting.md
  diagnostics.md
  versioning.md
  release-notes.md
  samples.md
  api/
    compatibility.md
  guides/
    core-semantics.md
    json-schema.md
    json-editor-compatibility.md
    ef-core.md
    power-bi.md
    system-text-json.md
    configuration-options.md
    projection-capabilities.md
  diagnostics/
    stm0xxx.md
    stm1xxx.md
    stm3xxx.md
    stm5xxx.md
  nuget/
    SemanticTypeModel.md
```

`release-notes.md` and detailed diagnostic range pages are retained from the repository unless separately
replaced by this overlay. Release notes are allowed to be historical; evergreen docs are not.

## Destructive actions

30 baseline paths are explicitly deleted:

- 5 superseded top-level/API consumer pages;
- 3 renamed guides;
- 1 stale preview diagnostic page;
- 7 per-sample pages;
- 13 per-package/generic NuGet README pages;
- 1 bootstrap-history engineering document.

## Anti-regrowth rules

- One shared NuGet README for the package suite.
- Package versions are aligned exactly across `SemanticTypeModel.*` references.
- Per-sample Markdown pages are not recreated.
- Public docs are organized by user task: use, configure, diagnose, reference.
- Evergreen docs do not carry release-candidate/milestone narration.
- A public generator option must be discoverable from `public-docs/configuration.md`.
- A public diagnostic must be discoverable from `public-docs/diagnostics.md` or its range page.
- A new public documentation file requires a distinct user task or audience, not merely a new feature.
