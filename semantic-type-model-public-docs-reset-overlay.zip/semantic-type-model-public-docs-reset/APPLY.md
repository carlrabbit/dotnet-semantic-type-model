# Apply the Public Documentation Reset Overlay

## Baseline

This overlay was prepared against repository `carlrabbit/dotnet-semantic-type-model`, branch
`codex/apply-documentation-reset-overlay`, commit:

```text
6a1540eef88eb2fecb984fb90842c01a716ca5d0
```

The overlay is intentionally destructive. It replaces the current public-documentation structure
with a smaller task-oriented surface and removes documentation that has become duplicate,
release-specific, or too weak to justify a separate synchronization surface.

## Goal

After application:

- a package consumer can find how to **use**, **configure**, and **diagnose** the library quickly;
- generator configuration, including generated namespace/provider-name settings, is discoverable from public docs;
- all `SemanticTypeModel.*` packages use one shared NuGet README;
- all package versions are treated as one aligned suite version;
- per-sample Markdown pages are removed; executable sample projects are the detailed examples;
- evergreen docs do not carry release-candidate archaeology;
- release chronology remains isolated in `public-docs/release-notes.md`;
- collaborator entry points are small routers into current authority;
- validation prevents the removed documentation structure and version drift from regrowing.

## Application Procedure

1. Record current HEAD and `git status --short`.
2. Compare current HEAD to baseline `6a1540e` before destructive actions.
3. Read `CLEANUP-MANIFEST.md` completely.
4. If any manifest path changed after the baseline, inspect the newer content before deleting it.
5. Copy the CONTENTS of `overlay/` onto the repository root.
6. Execute all `DELETE` and `EDIT` actions in `CLEANUP-MANIFEST.md`.
7. Search the complete repository for references to deleted paths and repair them.
8. Run the validation commands below.
9. Do not commit or push unless separately instructed.

## Divergence Rule

If a file listed for deletion contains genuinely newer current consumer information, promote that
information into the appropriate replacement authority before deleting the old file:

- basic use -> `README.md` or `public-docs/usage.md`;
- generator/library configuration -> `public-docs/configuration.md`;
- projection-specific use/configuration/errors -> the relevant `public-docs/guides/*.md`;
- troubleshooting -> `public-docs/troubleshooting.md`;
- diagnostic code details -> `public-docs/diagnostics.md` or `public-docs/diagnostics/*.md`;
- compatibility/migration history -> `public-docs/api/compatibility.md` or `public-docs/release-notes.md`;
- collaborator workflow -> `CONTRIBUTING.md`, `AGENTS.md`, or current `docs/engineering/*` authority.

Do not retain obsolete detail merely because it is detailed.

## Explicit Non-Goals

Do not use this cleanup to decide:

- which historical release candidates were actually published;
- a new package version number;
- manifest compatibility/version-evolution policy;
- unresolved `ValueObject` / `ValueKind` terminology;
- new runtime or projection behavior;
- source/test restructuring unrelated to documentation packaging.

## Validation

Required:

```sh
./eng/public-docs.sh
./eng/check.sh
```

Because package project files are edited to use one shared README, also inspect at least one packed
package if practical:

```sh
./eng/package.sh 0.0.0-docs
```

Confirm the package contains `README.md` sourced from
`public-docs/nuget/SemanticTypeModel.md`.

Do not publish.

## Completion Report

Report:

- starting and ending HEAD;
- replacement/new files applied;
- deleted paths;
- any post-baseline content promoted before deletion;
- all package projects changed to the shared README source;
- validation commands and results;
- final `git status --short`.
