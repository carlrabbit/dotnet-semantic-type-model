# Cleanup Manifest

Actions are relative to the repository root.

## Overlay replacements / additions

The files under `overlay/` are authoritative replacements/additions for this cleanup.

### Repository entry points

- REPLACE `README.md`
- ADD `CONTRIBUTING.md`
- REPLACE `AGENTS.md`
- REPLACE `.github/copilot-instructions.md`

### Public-documentation governance

- REPLACE `docs/PUBLIC-DOCS.md`
- REPLACE `docs/engineering/package-documentation.md`
- REPLACE `docs/engineering/public-documentation.md`
- REPLACE `docs/engineering/samples.md`
- REPLACE `docs/engineering/release-readiness.md`
- REPLACE `eng/public-docs.sh`

### Consumer documentation

- ADD `public-docs/usage.md`
- ADD `public-docs/configuration.md`
- ADD `public-docs/troubleshooting.md`
- REPLACE `public-docs/diagnostics.md`
- REPLACE `public-docs/versioning.md`
- REPLACE `public-docs/samples.md`
- ADD `public-docs/nuget/SemanticTypeModel.md`
- REPLACE `public-docs/api/compatibility.md`

### Task-oriented guides

- REPLACE `public-docs/guides/core-semantics.md`
- REPLACE `public-docs/guides/json-schema.md`
- REPLACE `public-docs/guides/json-editor-compatibility.md`
- ADD `public-docs/guides/ef-core.md`
- ADD `public-docs/guides/power-bi.md`
- REPLACE `public-docs/guides/system-text-json.md`
- ADD `public-docs/guides/configuration-options.md`
- REPLACE `public-docs/guides/projection-capabilities.md`

## Required project-file edit: one shared NuGet README

For every packable project returned by `semantic_type_model_package_projects` in `eng/common.sh`:

1. keep `<PackageReadmeFile>README.md</PackageReadmeFile>`;
2. replace the package-specific source include with exactly:

```xml
<None Include="../../public-docs/nuget/SemanticTypeModel.md" Pack="true" PackagePath="README.md" />
```

Do not maintain per-package README sources.

Expected package projects are the projects for:

- `SemanticTypeModel.Abstractions`
- `SemanticTypeModel.Core`
- `SemanticTypeModel.JsonSchema`
- `SemanticTypeModel.DotNet`
- `SemanticTypeModel.Generators`
- `SemanticTypeModel.DependencyInjection`
- `SemanticTypeModel.PowerBI`
- `SemanticTypeModel.EFCore`
- `SemanticTypeModel.EFCore.Generators`
- `SemanticTypeModel.SystemTextJson`
- `SemanticTypeModel.Configuration`
- `SemanticTypeModel.Configuration.Generators`

If `eng/common.sh` has a newer package inventory, apply the shared README mapping to that inventory too.

## DELETE: superseded top-level consumer pages

Their durable user tasks are consolidated into `usage.md`, `configuration.md`, guides, and the shared
NuGet README.

- `public-docs/getting-started.md`
- `public-docs/installation.md`
- `public-docs/concepts.md`
- `public-docs/packages.md`
- `public-docs/api/public-api.md`

## DELETE: renamed guides

- `public-docs/guides/ef-core-projection.md` -> replaced by `public-docs/guides/ef-core.md`
- `public-docs/guides/power-bi-projection.md` -> replaced by `public-docs/guides/power-bi.md`
- `public-docs/guides/configuration.md` -> replaced by `public-docs/guides/configuration-options.md`

## DELETE: stale preview diagnostic catalogue

- `public-docs/diagnostics/preview-status.md`

Do not re-document retired EF runtime/application diagnostics as current merely to preserve the old page.

## DELETE: per-sample Markdown pages

The executable project is the detailed sample. Keep only the compact index in `public-docs/samples.md`.

- `public-docs/samples/code-first-ef-core.md`
- `public-docs/samples/code-first-json-schema.md`
- `public-docs/samples/code-first-powerbi.md`
- `public-docs/samples/getting-started.md`
- `public-docs/samples/json-schema-roundtrip.md`
- `public-docs/samples/runtime-di.md`
- `public-docs/samples/system-text-json-resolver.md`

If a newer per-sample page was added after the baseline, inspect it before deletion and promote only
current user guidance that is not obvious from the sample itself.

## DELETE: per-package NuGet README sources

They are replaced by `public-docs/nuget/SemanticTypeModel.md`.

- `public-docs/nuget/SemanticTypeModel.Abstractions.md`
- `public-docs/nuget/SemanticTypeModel.Configuration.Generators.md`
- `public-docs/nuget/SemanticTypeModel.Configuration.md`
- `public-docs/nuget/SemanticTypeModel.Core.md`
- `public-docs/nuget/SemanticTypeModel.DependencyInjection.md`
- `public-docs/nuget/SemanticTypeModel.DotNet.md`
- `public-docs/nuget/SemanticTypeModel.EFCore.Generators.md`
- `public-docs/nuget/SemanticTypeModel.EFCore.md`
- `public-docs/nuget/SemanticTypeModel.Generators.md`
- `public-docs/nuget/SemanticTypeModel.JsonSchema.md`
- `public-docs/nuget/SemanticTypeModel.PowerBI.md`
- `public-docs/nuget/SemanticTypeModel.SystemTextJson.md`
- `public-docs/nuget/package-readme.md`

## DELETE: collaborator bootstrap history

- `docs/engineering/building-blocks.md`

Its applied/deferred building-block inventory is repository-bootstrap history, not current engineering authority.

## Reference repair

Search the whole repository for deleted path basenames and repair references. In particular replace links to:

- `public-docs/getting-started.md` -> `public-docs/usage.md`
- `public-docs/installation.md` -> `public-docs/usage.md`
- `public-docs/packages.md` -> `public-docs/nuget/SemanticTypeModel.md` or `public-docs/usage.md`
- `public-docs/guides/ef-core-projection.md` -> `public-docs/guides/ef-core.md`
- `public-docs/guides/power-bi-projection.md` -> `public-docs/guides/power-bi.md`
- `public-docs/guides/configuration.md` -> `public-docs/guides/configuration-options.md`
- `public-docs/samples/*.md` -> the actual `samples/<project>/` path or `public-docs/samples.md`

Do not create redirect Markdown files solely to retain the old paths.
