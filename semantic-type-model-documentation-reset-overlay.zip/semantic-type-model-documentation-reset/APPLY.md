# Apply the SemanticTypeModel Documentation Reset Overlay

## Purpose

This package is a repository transition, not only a file overlay. Files under `overlay/` replace or add repository files. `CLEANUP-MANIFEST.md` describes deletions and consolidations that cannot be represented by copying files.

The objective is to make the working tree describe **current project truth** while Git history retains detailed historical plans, superseded designs, and completed work orders.

## Baseline

This package was prepared from repository `carlrabbit/dotnet-semantic-type-model` at:

```text
53c6756cafc78793092d3e535e88a3a8f3c51012
```

That commit is the M0060 merge baseline described by the current-state handoff.

The package is safe to apply to a later commit only after reconciling divergence as described below.

## Apply Procedure

1. Confirm that the repository is `carlrabbit/dotnet-semantic-type-model`.
2. Record the current branch and commit.
3. Compare the current tree with baseline `53c6756` for every path listed in `CLEANUP-MANIFEST.md`.
4. If a listed historical file is unchanged since the baseline, use the manifest action directly.
5. If a listed file changed after the baseline, inspect the new material before destructive action. Do not discard current requirements or rationale merely because the path appears in the baseline cleanup list.
6. Copy the contents of `overlay/` into the repository root, preserving relative paths and replacing existing files where paths collide.
7. Execute the deletion and consolidation actions in `CLEANUP-MANIFEST.md`.
8. Search the complete repository for references to every deleted or replaced path. Repair indexes, links, agent instructions, comments, and scripts that still point at removed documentation.
9. Do **not** create `docs/archive/`, a milestone archive, or another repository copy of deleted historical documents. Git is the detailed historical store.
10. Do not recreate copied external setup/engineering guides under `docs/research/`.
11. Run the validation steps below.
12. Report the files added/replaced/deleted, any divergence from the manifest, and any material deliberately preserved because it was newer than the baseline.

## Deletion Safety Classification

Before deleting a historical or superseded document that has diverged from the baseline, classify unique material as follows:

| Material | Destination |
|---|---|
| Still-current behavioral requirement | Current subsystem specification |
| Still-current non-obvious rationale | Current decision |
| Architectural structure/boundary | Current architecture document |
| Useful architectural evolution context | `docs/HISTORY.md` |
| Consumer migration/version information | Compatibility or release documentation |
| Obsolete implementation detail | Delete with the historical source document |
| Duplicate of current authority | Delete |

Do not preserve obsolete material merely because it is detailed.

## Authority After This Reset

Use repository documents in this role-oriented way:

```text
AGENTS.md
    task routing and conditional reading

docs/specs/*
    exact current behavioral contracts

docs/architecture/*
    major structural boundaries and dependency direction

docs/decisions/*
    rationale for non-obvious choices that still constrain current/future work

docs/ENGINEERING.md + docs/engineering/*
    repository command, validation, packaging, and documentation lifecycle rules

docs/PUBLIC-DOCS.md + public-docs/*
    consumer-facing documentation authority

docs/MILESTONES.md + active docs/milestones/*
    current implementation sequencing only

docs/HISTORY.md
    concise architectural evolution

Git history
    detailed completed plans and superseded designs
```

A milestone never overrides a current specification or decision.

## Validation

This overlay is documentation-only unless the applying agent discovers and corrects implementation drift.

Minimum expected validation:

1. Verify Markdown/internal links for changed documentation.
2. Grep/search for references to all deleted paths and historical EF runtime-application terminology.
3. Run formatting/static checks appropriate to the repository's Tier 0 policy.
4. If public documentation is changed while reconciling references, run:

```sh
./eng/public-docs.sh
```

5. If implementation is changed as part of reconciliation, complete with:

```sh
./eng/check.sh
```

Do not run release/publish commands merely for this documentation cleanup.

## Explicit Non-Goals

Do not use this reset to decide any of the following unless separate current authority has been added after the baseline:

- semantic manifest compatibility/version-evolution policy;
- unresolved `ValueObject` versus `ValueKind` terminology semantics;
- actual current NuGet publication/stable-version truth;
- source/package/test restructuring unrelated to documentation;
- new EF provider-specific features.

Publication/version wording should be corrected only after actual package publication state is independently verified.
