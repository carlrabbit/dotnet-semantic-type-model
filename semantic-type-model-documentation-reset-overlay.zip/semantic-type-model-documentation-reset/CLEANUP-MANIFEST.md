# Cleanup Manifest

## Rules

- Paths are repository-relative.
- `DELETE` means remove the path from the working tree after applying the overlay and performing the safety check in `APPLY.md`.
- `REPLACE` means the overlay contains the complete replacement file.
- `MERGE -> DELETE` means durable current content has been incorporated into the named replacement authority; delete the old source after checking for post-baseline divergence.
- `REVIEW` is deliberately non-destructive. Do not delete solely because a path appears there.

## Replacement and New Authority Files

The overlay replaces or creates:

```text
AGENTS.md
docs/ARCHITECTURE.md
docs/DECISIONS.md
docs/ENGINEERING.md
docs/HISTORY.md
docs/MILESTONES.md
docs/RESEARCH.md
docs/SPECS.md
docs/architecture/code-first-domain-projection-pipeline.md
docs/decisions/ef-ownership-uses-target-role-and-storage-policy.md
docs/decisions/real-application-fixtures-are-required-for-ef-compatibility.md
docs/specs/ef-core.md
```

## Architecture Consolidation

Durable content from the two legacy architecture notes is represented by the replacement code-first architecture overview.

```text
MERGE -> DELETE docs/architecture/canonical-schema-model.md
MERGE -> DELETE docs/architecture/transformation-pipeline.md
```

Keep:

```text
docs/architecture/code-first-domain-projection-pipeline.md
```

## EF Core Specification Consolidation

`docs/specs/ef-core.md` becomes the current EF Core behavioral authority. It incorporates the current generated-configuration contract, narrow storage policy, composition boundary, and permanent real-provider testing requirements.

Delete the prior EF spec generations after confirming no post-baseline current material is unique:

```text
MERGE -> DELETE docs/specs/ef-convention-suppression-and-exact-entity-allowlist.md
MERGE -> DELETE docs/specs/ef-core-closed-modelbuilder-application.md
MERGE -> DELETE docs/specs/ef-core-clr-convention-suppression.md
MERGE -> DELETE docs/specs/ef-core-generated-configuration-contract.md
MERGE -> DELETE docs/specs/ef-core-real-application-regression-fixtures.md
MERGE -> DELETE docs/specs/ef-core-role-aware-owned-storage.md
MERGE -> DELETE docs/specs/ef-core-source-lineage-diagnostics.md
MERGE -> DELETE docs/specs/ef-core-source-lineage-scope-filtering.md
MERGE -> DELETE docs/specs/ef-model-shape-test-matrix-and-member-placement.md
MERGE -> DELETE docs/specs/opinionated-ef-relational-projection-contract.md
MERGE -> DELETE docs/specs/type-model-ef-core-projection.md
```

Do not recreate runtime `ApplySemanticTypeModel` / global `ModelBuilder` cleanup semantics in the consolidated spec.

## Superseded EF Decisions

The following decisions describe intermediate or retired EF application architectures and are superseded by the current generated-configuration architecture and the rewritten current storage/testing decisions:

```text
DELETE docs/decisions/ef-convention-discovery-is-corrected-before-validation.md
DELETE docs/decisions/ef-core-integration-stops-at-modelbuilder-configuration.md
DELETE docs/decisions/ef-requires-a-surgical-model-shape-test-matrix.md
DELETE docs/decisions/ef-source-lineage-is-diagnostic-first-and-application-policy-aware.md
DELETE docs/decisions/efcore-semantic-model-is-the-ef-application-contract.md
DELETE docs/decisions/reset-ef-core-projection-without-backward-compatibility.md
DELETE docs/decisions/separate-stm-ef-projection-from-clr-ef-convention-augmentation.md
```

Keep the current generated-configuration decision:

```text
docs/decisions/efcore-application-is-generated-configuration-code.md
```

The overlay rewrites these still-current independent decisions to remove obsolete milestone-era mechanics while preserving durable rationale:

```text
REPLACE docs/decisions/ef-ownership-uses-target-role-and-storage-policy.md
REPLACE docs/decisions/real-application-fixtures-are-required-for-ef-compatibility.md
```

## Explicitly Historical JSON Schema Decision

This file states in its own status that it is superseded and retained only as historical rationale. Git now carries that role.

```text
DELETE docs/decisions/json-schema-as-primary-dialect.md
```

## Completed Milestone Work Orders

All baseline milestone files M0001-M0060 are completed historical work orders. Their durable project truth is represented by current specs, decisions, architecture, engineering docs, public docs/tests, plus the new architectural `docs/HISTORY.md`.

Delete the completed milestone files. Do not move them to an archive directory. Continue future numbering with M0061.

```text
DELETE docs/milestones/m0001-project-and-engineering-setup.md
DELETE docs/milestones/m0002-baseline-semantic-type-model.md
DELETE docs/milestones/m0003-type-model-hardening.md
DELETE docs/milestones/m0004-json-schema-runtime-import-export-baseline.md
DELETE docs/milestones/m0005-transformation-pipeline-and-diagnostics-hardening.md
DELETE docs/milestones/m0006-json-editor-and-ui-projection-hints.md
DELETE docs/milestones/m0007-power-bi-tom-projection-prototype.md
DELETE docs/milestones/m0008-ef-core-dbmodel-projection-prototype.md
DELETE docs/milestones/m0009-dotnet-type-system-extraction-and-compile-time-generator-baseline.md
DELETE docs/milestones/m0010-attribute-and-convention-model-for-dotnet-type-extraction.md
DELETE docs/milestones/m0011-runtime-api-surface-and-di-integration.md
DELETE docs/milestones/m0012-documentation-samples-release-readiness-and-first-end-to-end-scenarios.md
DELETE docs/milestones/m0014-semantic-type-annotation-usability.md
DELETE docs/milestones/m0015-ef-core-projection-hardening.md
DELETE docs/milestones/m0016-end-to-end-code-first-schema-authoring-samples.md
DELETE docs/milestones/m0017-json-schema-projection-hardening-for-code-first-models.md
DELETE docs/milestones/m0018-diagnostics-documentation-and-analyzer-experience.md
DELETE docs/milestones/m0019-projection-capability-matrix-and-compatibility-contracts.md
DELETE docs/milestones/m0020-system-text-json-contract-integration.md
DELETE docs/milestones/m0021-power-bi-projection-hardening.md
DELETE docs/milestones/m0022-1-0-public-api-compatibility-documentation-samples-and-release-readiness.md
DELETE docs/milestones/m0023-1-0-0-release-hardening-and-final-release.md
DELETE docs/milestones/m0024-system-text-json-contract-correction.md
DELETE docs/milestones/m0025-consumer-facing-samples-and-package-based-sample-validation.md
DELETE docs/milestones/m0026-code-first-semantic-model-architecture-realignment.md
DELETE docs/milestones/m0027-query-and-inspection-api-for-code-first-semantic-models.md
DELETE docs/milestones/m0028-transformation-pipeline-and-domain-model-derivation.md
DELETE docs/milestones/m0029-json-schema-as-code-first-projection-only.md
DELETE docs/milestones/m0030-ef-core-domain-semantic-model-and-modelbuilder-projection.md
DELETE docs/milestones/m0031-power-bi-domain-semantic-model-and-local-metadata-projection.md
DELETE docs/milestones/m0032-core-semantic-vocabulary-and-envelope-semantics.md
DELETE docs/milestones/m0033-envelope-projection-policies-and-ef-core-owned-payload-storage.md
DELETE docs/milestones/m0034-evolution-ownership-and-lifecycle-semantics.md
DELETE docs/milestones/m0035-remove-legacy-model-compatibility-and-align-system-text-json-projection.md
DELETE docs/milestones/m0036-adopt-external-agentic-project-guide-system-v0.3.0.md
DELETE docs/milestones/m0037-documentation-synchronization-and-2-1-0-release-preparation.md
DELETE docs/milestones/m0038-collapse-model-canonical-split-and-align-generator-output.md
DELETE docs/milestones/m0039-documentation-synchronization-and-2-2-0-release-preparation.md
DELETE docs/milestones/m0040-configuration-domain-model-and-options-registration-projection.md
DELETE docs/milestones/m0041-remove-stale-public-api-baselines-and-standardize-package-documentation.md
DELETE docs/milestones/m0042-rewrite-package-readmes-and-usage-guides-to-documentation-standard.md
DELETE docs/milestones/m0043-expand-usage-guides-with-concrete-options-policies-and-supported-items.md
DELETE docs/milestones/m0044-explicit-per-type-configuration-registration-and-required-section-presence.md
DELETE docs/milestones/m0045-documentation-synchronization-and-2-3-0-release-preparation.md
DELETE docs/milestones/m0046-shared-order-fulfillment-samples-and-scalar-nullability-compatibility-hardening.md
DELETE docs/milestones/m0047-audience-specific-descriptions-and-projection-description-policies.md
DELETE docs/milestones/m0048-documentation-synchronization-and-2-4-0-release-preparation.md
DELETE docs/milestones/m0049-emergency-dictionary-type-extraction-fix-and-2-4-1-patch-release.md
DELETE docs/milestones/m0050-format-compatible-scalar-support-and-role-aware-ef-owned-storage.md
DELETE docs/milestones/m0051-ef-clr-convention-suppression-and-valueobject-boundary-hardening.md
DELETE docs/milestones/m0052-closed-ef-core-semantic-model-application-and-2-4-4-release-preparation.md
DELETE docs/milestones/m0053-ef-source-lineage-diagnostics-and-derivation-application-policy-for-2-4-5.md
DELETE docs/milestones/m0054-real-application-ef-regression-fixtures-and-2-4-6-release-preparation.md
DELETE docs/milestones/m0055-opinionated-relational-projection-contract-and-ef-core-package-reset-for-2-5-0.md
DELETE docs/milestones/m0056-preemptive-ef-convention-suppression-and-2-5-1-release-preparation.md
DELETE docs/milestones/m0057-ef-model-shape-test-matrix-and-inherited-member-placement-for-2-5-3.md
DELETE docs/milestones/m0058-typed-literals-conditional-constraints-and-scalar-semantics-for-2-6-0.md
DELETE docs/milestones/m0059-ef-clr-to-provider-regression-and-2-6-1.md
DELETE docs/milestones/m0060-generated-ef-entity-configurations-and-composable-ef-integration-for-3-0-0.md
```

There was no M0013 milestone file in the baseline tree. Do not invent one.

Also delete the committed patch artifact:

```text
DELETE docs/MILESTONES.md.patch.md
```

## Historical Root Overlay Archives

These are completed milestone transport artifacts, not current repository truth:

```text
DELETE m0050-format-compatible-scalar-support-and-role-aware-ef-owned-storage.zip
DELETE m0051-ef-clr-convention-suppression-and-valueobject-boundary-hardening.zip
DELETE m0052-closed-ef-core-semantic-model-application-and-2-4-4-release-preparation.zip
DELETE m0053-ef-source-lineage-diagnostics-and-derivation-application-policy-for-2-4-5.zip
DELETE m0054-real-application-ef-regression-fixtures-and-2-4-6-release-preparation.zip
DELETE m0055-opinionated-relational-projection-contract-and-ef-core-package-reset-for-2-5-0.zip
DELETE m0056-preemptive-ef-convention-suppression-and-2-5-1-release-preparation.zip
DELETE m0057-ef-model-shape-test-matrix-and-inherited-member-placement-for-2-5-3.zip
DELETE m0058-typed-literals-conditional-constraints-and-scalar-semantics-for-2-6-0.zip
DELETE m0059-ef-clr-to-provider-regression-and-2-6-1.zip
DELETE m0060-generated-ef-entity-configurations-and-composable-ef-integration-for-3-0-0.zip
```

Future milestone overlays should be transport artifacts, not committed repository history unless a specific current requirement says otherwise.

## Copied External Guides Under Research

External guide copies are non-authoritative and should not be retained in the repository:

```text
DELETE docs/research/engineering-guide-v4.md
DELETE docs/research/engineering-guide-v5.md
DELETE docs/research/project-setup-guide-v5.md
DELETE docs/research/project-setup-guide-v6.md
```

The replacement `docs/RESEARCH.md` defines the policy going forward.

## Stale Guide-Synchronization Queue

At the baseline, `.guide-sync/pending/` contains old milestone/release-follow-up notes rather than only unresolved current synchronization work.

Delete these baseline entries:

```text
DELETE .guide-sync/pending/guide-system-adoption-cleanup.md
DELETE .guide-sync/pending/m0038-model-surface-unification.md
DELETE .guide-sync/pending/m0039-documentation-sync-and-2-2-0-release-preparation.md
DELETE .guide-sync/pending/m0040-configuration-domain-and-options-projection.md
DELETE .guide-sync/pending/m0041-package-documentation-standardization.md
DELETE .guide-sync/pending/m0042-package-readme-and-usage-guide-rewrite.md
DELETE .guide-sync/pending/m0043-usage-guide-supported-items-and-policy-precision.md
DELETE .guide-sync/pending/m0044-explicit-configuration-registration-and-section-presence.md
DELETE .guide-sync/pending/m0045-2-3-0-publication-follow-up.md
DELETE .guide-sync/pending/m0046-shared-samples-and-nullability-hardening.md
DELETE .guide-sync/pending/m0047-audience-specific-descriptions.md
DELETE .guide-sync/pending/m0048-2-4-0-publication-follow-up.md
DELETE .guide-sync/pending/m0049-2-4-1-publication-follow-up.md
DELETE .guide-sync/pending/m0050-2-4-2-publication-follow-up.md
DELETE .guide-sync/pending/m0051-2-4-3-publication-follow-up.md
DELETE .guide-sync/pending/m0052-2-4-4-publication-follow-up.md
DELETE .guide-sync/pending/m0053-2-4-5-publication-follow-up.md
DELETE .guide-sync/pending/m0054-2-4-6-publication-follow-up.md
DELETE .guide-sync/pending/m0055-2-5-0-publication-follow-up.md
DELETE .guide-sync/pending/m0056-2-5-1-publication-follow-up.md
DELETE .guide-sync/pending/m0057-2-5-3-publication-follow-up.md
DELETE .guide-sync/pending/m0058-2-6-0-publication-follow-up.md
```

If a later branch has a genuinely unresolved synchronization item, preserve only that current unresolved item or rewrite it as a current pending item. `.guide-sync/pending/` should normally be empty.

## Review-Only Consolidation Candidates

These families appear to overlap historically, but this overlay deliberately does not delete them because the available current-state evidence is insufficient to prove that every detailed requirement is duplicated elsewhere.

The applying agent may consolidate them only after a full content audit and tests/source verification:

```text
REVIEW core model family:
  docs/specs/core-semantic-vocabulary.md
  docs/specs/current-canonical-model-surface.md
  docs/specs/model-surface-unification.md
  docs/specs/type-model-core.md
  docs/specs/type-schema-model.md

REVIEW .NET/code-first family:
  docs/specs/code-first-semantic-model-architecture.md
  docs/specs/type-model-annotations.md
  docs/specs/type-model-dotnet-attributes.md
  docs/specs/type-model-dotnet-conventions.md
  docs/specs/type-model-dotnet-extraction.md

REVIEW JSON Schema family:
  docs/specs/json-schema-adapter.md
  docs/specs/json-schema-domain-model-and-export.md
  docs/specs/type-model-json-schema-mapping.md

REVIEW System.Text.Json family:
  docs/specs/system-text-json-contract-integration.md
  docs/specs/system-text-json-domain-model-and-resolver-projection.md
```

Do not create new specs merely to perform this review. Prefer extending/merging into the strongest current subsystem contract.

## Public Documentation

This reset is intentionally conservative with `public-docs/` and package README sources. Do not merge package-specific consumer entry points simply to reduce file count.

Version/publication reconciliation is deferred until actual package publication state is verified. Do not guess a stable version from repository milestones, package inventory, or source presence.
