# Reset Inventory

## Scope Summary

This reset deliberately removes material that is clearly historical or superseded and consolidates the most structurally broken authority area: EF Core.

Baseline destructive actions represented by `CLEANUP-MANIFEST.md`:

| Class | Baseline paths | Action |
|---|---:|---|
| Completed milestone Markdown | 59 | Delete after durable-truth check |
| Historical root milestone ZIPs | 11 | Delete |
| Stale guide-sync pending items | 22 | Delete unless genuinely unresolved on later branch |
| Copied external research guides | 4 | Delete |
| Superseded/merged EF specs | 11 | Merge into `docs/specs/ef-core.md`, then delete |
| Superseded EF decisions | 7 | Delete |
| Explicitly historical JSON Schema decision | 1 | Delete |
| Legacy architecture notes | 2 | Merge into current architecture, then delete |
| Patch artifact | 1 | Delete |

Total baseline destructive paths: **118**.

## Files Supplied by the Overlay

| Path | Role |
|---|---|
| `AGENTS.md` | Agent routing and authority hierarchy |
| `docs/ARCHITECTURE.md` | Architecture index |
| `docs/DECISIONS.md` | Current-decision index and lifecycle |
| `docs/ENGINEERING.md` | Existing engineering contract plus documentation lifecycle rules |
| `docs/HISTORY.md` | Concise architectural evolution |
| `docs/MILESTONES.md` | Active-work lifecycle and next number M0061 |
| `docs/RESEARCH.md` | Research policy; removes copied-guide authority |
| `docs/SPECS.md` | Current spec routing, with one EF authority |
| `docs/architecture/code-first-domain-projection-pipeline.md` | Consolidated current structural architecture |
| `docs/decisions/ef-ownership-uses-target-role-and-storage-policy.md` | Current projection-neutral ownership/storage rationale |
| `docs/decisions/real-application-fixtures-are-required-for-ef-compatibility.md` | Current boundary/integration testing rationale |
| `docs/specs/ef-core.md` | Consolidated current EF Core contract |

## Deliberately Preserved

- `docs/TERMINOLOGY.md` — terminology needs a separate semantic decision before resolving `ValueObject`/`ValueKind` ambiguity.
- Non-EF subsystem specs — preserved unless clearly superseded; selected overlap families are review-only in the cleanup manifest.
- Package/public documentation — separate consumer entry points remain useful; version/publication claims require verified external release truth before rewriting.
- Current non-EF decisions — retained unless their own status or later authority proves them superseded.
- Source, tests, package projects, and build scripts — this overlay is a documentation reset, not an implementation rewrite.

## Anti-Regrowth Rule

Default to changing an existing authoritative document.

A new documentation file requires a distinct authority boundary, such as:

- a new independently implementable subsystem contract;
- a new durable non-obvious architectural decision;
- a new consumer/package/audience entry point;
- an active milestone;
- a genuinely separate active research subject.

A feature, bug fix, diagnostic, mapping option, release, or milestone implementation detail normally extends existing authority instead of creating a new document.
