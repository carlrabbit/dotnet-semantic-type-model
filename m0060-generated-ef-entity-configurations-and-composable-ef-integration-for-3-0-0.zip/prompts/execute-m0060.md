# Execute M0060 — Generated EF Entity Configurations and Composable EF Integration

Implement:

```text
docs/milestones/m0060-generated-ef-entity-configurations-and-composable-ef-integration-for-3-0-0.md
```

Repository:

```text
carlrabbit/dotnet-semantic-type-model
```

Target release:

```text
3.0.0
```

New package:

```text
SemanticTypeModel.EFCore.Generators
```

## Required Architecture

Replace the runtime global `ModelBuilder` cleanup/application mechanism with source-generated ordinary EF Core configuration.

The canonical flow is:

```text
semantic model assembly
→ deterministic compile-time semantic manifest
→ persistence project explicitly selects semantic model(s)
→ SemanticTypeModel.EFCore.Generators
→ IEntityTypeConfiguration<TEntity> per semantic Entity
→ deterministic Apply<Model>() extension
→ normal EF Core model building
```

Central invariant:

> A generated semantic EF model may configure only the CLR entity types it owns. It must never inspect, remove, ignore, reject, or validate unrelated EF entity types in the surrounding DbContext.

## Fixed Decisions

Implement these unless repository authority directly conflicts:

```text
generation runs in the EF/persistence project
model selection uses explicit assembly attributes
new package is SemanticTypeModel.EFCore.Generators
generated configuration classes are internal partial
only semantic Entity gets IEntityTypeConfiguration<T>
ValueKinds/enums/nonentities do not
generated registration extension is public
registration order is deterministic, base before derived
hooks are ConfigureBeforeGenerated and ConfigureAfterGenerated only
AfterGenerated is the normal application override/hotfix point
generated source uses direct EF Core calls
runtime helpers are limited to converter/comparer/helper primitives
multiple semantic models in one DbContext are supported
same CLR entity in two selected models is a generator error
manual unrelated EF entities are supported
no per-entity generation opt-out
no materializing dotnet tool
runtime ApplySemanticTypeModel/ApplySemanticRelationalModel path is removed
```

## Execution Sequence

1. Read `AGENTS.md`, M0060, `docs/ENGINEERING.md`, command contract, package-documentation rules, and directly affected EF specs/decisions.
2. Inspect current `SemanticTypeModel.Generators`, `SemanticTypeModel.EFCore`, package scripts, package smoke, docs validation, solution, and GitHub workflows.
3. Define a versioned semantic generator manifest readable from referenced assembly metadata without executing referenced application assemblies.
4. Extend `SemanticTypeModel.Generators` to emit the manifest.
5. Add the explicit model-selection attribute/API to `SemanticTypeModel.EFCore`.
6. Add `src/SemanticTypeModel.EFCore.Generators/` as an analyzer/source-generator package.
7. Reuse/refactor the pure EF relational rules; do not create a second hand-maintained mapping algorithm or another public package solely for sharing.
8. Generate one `IEntityTypeConfiguration<TEntity>` per semantic Entity.
9. Add `ConfigureBeforeGenerated` and `ConfigureAfterGenerated`.
10. Generate one explicit deterministic public `Apply<Model>()` extension per selected model.
11. Add manifest/model-selection/name/duplicate-ownership diagnostics.
12. Add dedicated generator tests.
13. Add a real multi-model `DbContext` test containing model A, model B, and a manual unrelated entity.
14. Prove no generated model removes/rejects another model or the manual entity.
15. Add a provider-backed `ConfigureAfterGenerated` customization test.
16. Remove runtime global cleanup/application APIs and obsolete tests.
17. Preserve current Entity/TPT/scalar/enum/strong-id/binary/JSON ValueKind persistence rules.
18. Update the EF sample.
19. Add new source/test projects to `SemanticTypeModel.slnx`.
20. Add the package ID/project to `eng/common.sh`.
21. Refactor `eng/public-docs.sh` so package IDs/projects come from the canonical inventory rather than a second independent list.
22. Update package smoke so the packed `.nupkg` generator is actually executed.
23. Add/update package README and all directly affected docs.
24. Add the generated-configuration decision/spec and supersede old runtime cleanup/application authority.
25. Review CI/pack/release/publish workflows. Keep script-driven inventory and avoid hardcoded package lists in YAML.
26. Run focused tests, `eng/check.sh`, package/docs validation, and full `3.0.0` release check.
27. Inspect the new `.nupkg`.
28. Stop before publishing.
29. Complete M0060 completion notes with evidence.

## Representative Generated Shape

```csharp
internal partial class ImportSpecificationConfiguration
    : IEntityTypeConfiguration<ImportSpecification>
{
    public void Configure(
        EntityTypeBuilder<ImportSpecification> builder)
    {
        ConfigureBeforeGenerated(builder);
        ConfigureGenerated(builder);
        ConfigureAfterGenerated(builder);
    }

    private static void ConfigureGenerated(
        EntityTypeBuilder<ImportSpecification> builder)
    {
        // Direct EF Core API calls.
    }

    static partial void ConfigureBeforeGenerated(
        EntityTypeBuilder<ImportSpecification> builder);

    static partial void ConfigureAfterGenerated(
        EntityTypeBuilder<ImportSpecification> builder);
}
```

Consumer:

```csharp
internal partial class ImportSpecificationConfiguration
{
    static partial void ConfigureAfterGenerated(
        EntityTypeBuilder<ImportSpecification> builder)
    {
        builder.HasIndex(x => x.DisplayName);
    }
}
```

## Package Integration Surfaces

Verify/update:

```text
SemanticTypeModel.slnx
eng/common.sh
eng/package.sh
eng/package-smoke.sh
tests/package-smoke/*
eng/public-docs.sh
eng/publish.sh
.github/workflows/ci.yml
.github/workflows/pack.yml
.github/workflows/release-check.yml
.github/workflows/publish-nuget.yml
README.md
docs/PUBLIC-DOCS.md
public-docs/packages.md
public-docs/nuget/SemanticTypeModel.EFCore.Generators.md
```

Do not merely create the package project. Prove its analyzer executes from the packed package.

## Documentation

Update at minimum:

```text
README.md
docs/PUBLIC-DOCS.md
docs/MILESTONES.md
public-docs/packages.md
public-docs/installation.md
public-docs/getting-started.md
public-docs/guides/ef-core-projection.md
public-docs/guides/projection-capabilities.md
public-docs/nuget/SemanticTypeModel.EFCore.md
public-docs/nuget/SemanticTypeModel.EFCore.Generators.md
public-docs/samples/code-first-ef-core.md
public-docs/api/compatibility.md
public-docs/api/public-api.md
public-docs/release-notes.md
samples/code-first-ef-core/
```

Document generated-source inspection and optional physical generated files:

```xml
<PropertyGroup>
  <EmitCompilerGeneratedFiles>true</EmitCompilerGeneratedFiles>
  <CompilerGeneratedFilesOutputPath>
    $(BaseIntermediateOutputPath)Generated
  </CompilerGeneratedFilesOutputPath>
</PropertyGroup>
```

## Required Tests

```text
one generated configuration per Entity
none for ValueKind/enum/nonentity
enum string mapping
JSON ValueKind mapping
strong-id/binary mapping
TPT order
inherited member placement
deterministic generated text
before/after hook compilation
AfterGenerated modifies finalized model
manifest selection/errors/versioning
duplicate CLR entity ownership diagnostic
two semantic models + manual entity in one DbContext
SQLite finalization / EnsureCreated / save / reload
packed nupkg generator execution
```

## Validation

```sh
./eng/test-filter.sh M0060
./eng/test-filter.sh EFCoreGenerator
./eng/test-filter.sh GeneratedConfiguration
./eng/test-filter.sh MultiModel
./eng/test-filter.sh PartialHook

./eng/test-project.sh tests/unit/SemanticTypeModel.EFCore.Generators.Tests.Unit
./eng/test-project.sh tests/unit/SemanticTypeModel.EFCore.Tests.Unit
./eng/test-project.sh tests/integration/SemanticTypeModel.EFCore.Tests.Integration

./eng/check.sh

./eng/package.sh 3.0.0
./eng/package-smoke.sh 3.0.0
./eng/samples.sh
./eng/public-docs.sh
./eng/release-check.sh 3.0.0
```

Inspect:

```sh
find artifacts/nuget -maxdepth 1 -type f -print | sort
unzip -l artifacts/nuget/SemanticTypeModel.EFCore.Generators.3.0.0.nupkg
```

Do not run:

```sh
./eng/publish.sh 3.0.0
```

## Final Report

Report:

```text
model-selection API
semantic manifest contract/version
generator package structure
runtime APIs removed
generated source example
partial override evidence
multi-model/manual entity evidence
diagnostics
solution/build changes
canonical package inventory
package-smoke evidence
documentation changes
workflow changes or no-change rationale
focused tests
eng/check.sh
3.0.0 package inventory
new nupkg inventory
release-check
public API/compatibility result
remaining risks
publication status
```

Do not claim completion if the generator was tested only via project reference.
