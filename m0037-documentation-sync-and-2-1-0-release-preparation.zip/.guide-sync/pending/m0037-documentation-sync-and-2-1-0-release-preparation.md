# Pending Guide Sync — M0037 Documentation Sync and 2.1.0 Release Preparation

## Purpose

Track deferred documentation synchronization and release-readiness checks that should be considered when executing M0037.

## Scope

Execution mode:

```text
documentation-sync + release-readiness
```

This hint may be read by the M0037 implementation agent because the milestone explicitly performs documentation synchronization and release preparation.

Ordinary implementation agents must not be required to read `.guide-sync/`.

## Pending Checks

### Repository authority indexes

Review and update when corresponding files exist:

```text
docs/MILESTONES.md
docs/SPECS.md
docs/DECISIONS.md
docs/TERMINOLOGY.md
```

Expected new or recent docs to consider:

```text
docs/milestones/m0033-envelope-projection-policies-and-ef-core-owned-payload-storage.md
docs/milestones/m0034-evolution-ownership-and-lifecycle-semantics.md
docs/milestones/m0035-remove-legacy-model-compatibility-and-align-system-text-json-projection.md
docs/milestones/m0036-adopt-external-agentic-project-guide-system-v0.3.0.md
docs/milestones/m0037-documentation-synchronization-and-2-1-0-release-preparation.md
docs/specs/envelope-projection-policies.md
docs/specs/evolution-ownership-and-lifecycle-semantics.md
docs/specs/current-canonical-model-surface.md
docs/specs/system-text-json-domain-model-and-resolver-projection.md
docs/decisions/envelope-projection-policies-are-target-specific.md
docs/decisions/evolution-semantics-remain-projection-neutral.md
docs/decisions/remove-legacy-model-compatibility-and-hardened-terminology.md
```

### Public documentation

Review and update when behavior is implemented:

```text
README.md
public-docs/getting-started.md
public-docs/installation.md
public-docs/concepts.md
public-docs/packages.md
public-docs/samples.md
public-docs/api/compatibility.md
public-docs/diagnostics.md
public-docs/versioning.md
public-docs/release-notes.md
public-docs/guides/core-semantics.md
public-docs/guides/json-schema.md
public-docs/guides/ef-core-projection.md
public-docs/guides/power-bi-projection.md
public-docs/guides/system-text-json.md
public-docs/nuget/*.md
public-docs/samples/*.md
```

### Release-readiness checks

Before declaring the 2.1.0 candidate ready, run:

```sh
./eng/public-docs.sh
./eng/release-check.sh 2.1.0
```

### Human review

Record review outcomes for:

```text
release notes
breaking-change classification
public API baseline changes
package version choice
sample scope
publish/no-publish decision
```

## Resolution Rule

Delete this hint or replace it with a resolved note when M0037 has synchronized the affected docs and release readiness has either passed or been explicitly blocked by a tracked follow-up.
