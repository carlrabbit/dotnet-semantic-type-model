# Documentation Sync Hint — M0061 Guide System and Post-EF Consolidation

## Source

Milestone:

- `docs/milestones/m0061-guide-system-and-post-ef-consolidation.md`

Created by:

- migration/consolidation planning package

## Status

Pending.

## Reason

M0061 directly updates documentation that would otherwise become false because of package/API removals and manifest/engineering-command changes.

This hint exists only for residual normalization that is not required to make current authority correct during implementation.

## Affected Areas

Potentially:

- `AGENTS.md`
- `docs/ARCHITECTURE.md`
- `docs/ENGINEERING.md`
- `docs/engineering/command-contract.md`
- `docs/SPECS.md`
- `docs/PUBLIC-DOCS.md`
- `docs/TERMINOLOGY.md`
- relevant architecture/spec/decision documents
- `README.md`
- `public-docs/`
- shared NuGet README/package documentation

## Suggested Sync Work

After implementation:

- verify no active documentation references `SemanticTypeModel.Configuration.Generators`;
- verify JSON Schema documentation describes export/projection only, not canonical-model import;
- verify manifest documentation calls the assembly manifest ephemeral internal compile-time transport and does not promise persistence compatibility;
- verify exact SemanticTypeModel suite-version requirements are stated consistently where generator composition is documented;
- verify engineering documentation describes `eng/` as the stable API and tested .NET code as the home for non-trivial engineering semantics;
- verify projection/application ownership language is consistent across architecture and affected public guides;
- remove stale migration narration that belongs only in Git history;
- after M0061 completion, remove the milestone and restore `docs/MILESTONES.md` to no-active-milestone state with M0062 next;
- delete this hint when all remaining items are resolved.

## Not In Scope

- new semantic/projection features;
- further EF redesign;
- new package creation;
- release publication;
- guide-document copies;
- TBPs or issue templates.

## Completion Criteria

- current authority matches implemented M0061 behavior;
- no removed package/API remains documented as supported;
- no external guide document is operational authority;
- residual synchronization work is complete;
- this hint is deleted.

## Remaining Blockers

- None known at planning time.
