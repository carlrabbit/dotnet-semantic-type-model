# M0061 — Guide System and Post-EF Consolidation

## Execution Profile

| Field | Value |
|---|---|
| Mode | ai-executed-human-reviewed |
| Scope size | medium-large |
| Implementation autonomy | high |
| Documentation sync | deferred except directly contradicted authority |
| Local validation | Tier 1 throughout implementation |
| Completion validation | Tier 2 plus affected package/public-doc/package-smoke validation |
| Human review | normal repository review; do not activate formal `.review/` infrastructure in this milestone |

## Goal

Perform one consolidation milestone after the EF Core application rewrite.

The milestone combines:

1. migration from guide-system metadata v0.3.0 to the latest resolved guide-system version, **v0.6.0**;
2. modernization of complex `eng/` command implementations while preserving the existing `eng/` command API;
3. hardening the ephemeral compile-time semantic manifest with exact SemanticTypeModel suite-version matching;
4. removing unused/legacy compatibility surfaces instead of preserving backwards compatibility;
5. preserving the new post-EF architectural ownership rules across the package family.

This milestone is intentionally consolidation work. It must not introduce new semantic-model features or broaden projection scope.

## Resolved Guide Version

Resolved latest external guide-system version: **0.6.0**.

Planning resolution used the external guide repository:

- `README.md`;
- `CHANGELOG.md`;
- `meta/VERSIONING.md`;
- `meta/MIGRATION-MODEL.md`;
- current decisions;
- migration chain from v0.3.0 through v0.6.0;
- `templates/PROMPTS.md`;
- current guide-profile model.

The external guide repository is planning/migration methodology only. Ordinary implementation agents must not use it as operational authority and do not need to read it.

## Required Authority

Read these repository-local files before implementation:

- `AGENTS.md`
- `docs/ARCHITECTURE.md`
- `docs/architecture/code-first-domain-projection-pipeline.md`
- `docs/SPECS.md`
- `docs/ENGINEERING.md`
- `docs/engineering/command-contract.md`
- `docs/PUBLIC-DOCS.md`
- `docs/MILESTONES.md`

For each source area changed, also read the directly relevant current spec/decision/public guide routed by `AGENTS.md`.

Treat `.guide-profile.json` and `.guide-sync/` as planning/synchronization metadata, not implementation authority.

## Architectural Rules

Preserve these invariants throughout M0061:

1. The canonical `TypeSchemaModel` owns semantic meaning.
2. Projection packages own target representation choices.
3. Applications own global framework/application composition.
4. A projection configures or emits only artifacts it semantically owns.
5. Application-specific behavior should use the target framework's normal extension points before expanding canonical STM vocabulary.
6. The semantic manifest is ephemeral compile-time transport, not a public or persistable authoring format.
7. All `SemanticTypeModel.*` packages used together must match exactly.
8. Do not add compatibility shims for surfaces deliberately removed in this consolidation.
9. Generated-source mechanisms are used only where they solve a real integration boundary; do not generalize EF's generator architecture to every projection.

## Migration Classification

| Area | Classification | Action |
|---|---|---|
| Guide profile v0.3.0 -> v0.6.0 | **required** | Replace `.guide-profile.json` with the supplied v0.6.0 metadata. |
| Repository-local authority | **no-op / preserve** | Keep `AGENTS.md` localized; do not add external guide required-reading. |
| Copied guide documents | **deprecated** | None should exist; delete any discovered old setup/engineering guide copies rather than preserving them. |
| Engineering command API (`eng/`) | **preserve** | Existing command names remain the stable human/agent/CI API. |
| Complex shell engineering semantics | **required** | Move non-trivial policy/filtering/parsing/orchestration semantics to tested .NET engineering code. |
| Resumable validation | **conditional** | Add only where a specific aggregate command demonstrably exceeds agent execution constraints. |
| Formal `.review/` subsystem | **no-op / conditional** | Do not introduce it. If added later, use milestone-scoped semantics. |
| Semantic manifest suite version | **required** | Add producer STM version and exact-version consumer validation. |
| Manifest compatibility negotiation | **deprecated / do not add** | No reader ranges, adapters, feature negotiation, or stored-manifest guarantees. |
| `SemanticTypeModel.Configuration.Generators` | **required removal** | Remove placeholder package and all active inventory/docs/build references. |
| JSON Schema import compatibility surface | **required removal** | Remove retained importer/API rather than deprecating or preserving it. |
| Configuration derivation/integration source organization | **recommended / in scope** | Separate derivation/domain logic from options/DI integration internally without adding a package. |
| Other projections | **no-op / audit only** | Preserve current boundaries unless implementation reveals a direct contradiction. |
| New product features | **out of scope** | Do not add new semantic/projection capabilities. |

## Focus Area A — Upgrade guide-system metadata

### Purpose

Move the repository from legacy v0.3.0 guide-selection metadata to the current v0.6.0 metadata shape without importing guide authority into the product repository.

### Files likely affected

- `.guide-profile.json`
- `docs/MILESTONES.md`
- `.guide-sync/pending/m0061-guide-system-and-post-ef-consolidation.md`

### Acceptance criteria

- guide system records `carlrabbit/agentic-project-guides` v0.6.0;
- profiles are `base` and `dotnet-library`;
- repository role is `capability-provider`;
- maturity is `published-maintenance`;
- implementation mode remains `ai-executed-human-reviewed`;
- documentation sync and release readiness remain separate passes;
- formal human-review semantics, if ever activated, are milestone-scoped;
- external guides are not copied or referenced as ordinary implementation authority;
- TBPs and issue templates remain inactive.

### Validation

```sh
python3 -m json.tool .guide-profile.json >/dev/null
git diff --check
```

## Focus Area B — Modernize engineering command implementation

### Purpose

Preserve `eng/` as the stable engineering API while moving complex repository policy and engineering semantics out of large shell/Python-in-shell implementations into tested .NET code.

### Required design

Use a repository-local engineering command host/project when logic is beyond trivial process launching.

Preferred shape:

```text
eng/<command>.sh
    -> thin launcher
    -> repository engineering command host
    -> tested command/domain implementation
```

Do **not** wrap trivial one-command scripts merely for consistency.

### Required assessment

Classify every current `eng/*.sh` command as one of:

- Level 1 — direct thin script;
- Level 2 — modest orchestration/helper;
- Level 3 — tested engineering command implementation required.

At minimum, treat the following as Level 3 candidates requiring migration unless inspection proves otherwise:

- `eng/check-affected.sh`;
- `eng/public-docs.sh`;
- `eng/package-smoke.sh`.

Also inspect:

- `eng/samples.sh`;
- `eng/release-check.sh`;
- `eng/publish.sh`;
- package/release inventory logic in `eng/common.sh`.

### Semantics that belong in tested code

Examples include:

- affected-path classification;
- repository/package policy validation;
- JSON/XML parsing;
- link/document graph validation;
- package inventory consistency;
- artifact/package-smoke scenario orchestration when non-trivial;
- manifests/fingerprints/receipts if later introduced;
- complex filtering or workspace resolution.

### Semantics that may remain in shell

Examples:

- invoking `dotnet restore`;
- invoking `dotnet build`;
- invoking a test project;
- forwarding arguments;
- setting straightforward environment variables;
- composing a few simple subprocesses when no repository-domain policy is encoded.

### Compatibility

Preserve current public engineering command names and expected exit-code behavior unless an existing command contract is internally inconsistent.

Shell launchers must forward arguments and command failure correctly.

### Tests

Add focused automated tests for migrated engineering semantics. The tests should validate policy/routing behavior without executing full release workflows unnecessarily.

### Resumable validation

Do not introduce `--list`, `--plan-json`, `--shard`, receipts, fingerprints, or aggregate verifier infrastructure merely because guide-system v0.5 supports it.

Introduce such machinery only for a concrete validation suite that cannot reliably finish within the relevant agent/harness execution budget.

## Focus Area C — Make manifest version alignment explicit

### Purpose

Treat the assembly semantic manifest as ephemeral generator-to-generator build metadata and enforce the repository's exact-version package rule.

### `SemanticTypeModel.Generators`

Add SemanticTypeModel producer suite version to the emitted manifest/envelope.

Keep manifest schema versioning simple. Do not create compatibility-range machinery.

Conceptually:

```json
{
  "version": 1,
  "semanticTypeModelVersion": "<package-version>",
  "modelName": "...",
  "types": []
}
```

If adding the field is compatible with the current wire representation, keep schema version `1`.

### `SemanticTypeModel.EFCore.Generators`

On manifest consumption:

1. validate the recognized manifest schema;
2. validate that the manifest's producing SemanticTypeModel version exactly matches the consuming generator's SemanticTypeModel version;
3. stop generation for that selected model on mismatch;
4. produce a deterministic actionable diagnostic identifying both versions.

### Contract

Document current behavior as:

> The semantic manifest is internal, regenerated compile-time metadata between aligned SemanticTypeModel generator packages. Cross-version manifest consumption and persisted-manifest compatibility are unsupported.

### Non-goals

Do not add:

- minimum-reader versions;
- compatibility matrices;
- adapters for old manifest versions;
- feature negotiation;
- public manifest APIs;
- guarantees for storing/reusing manifests independently of the producing build.

### Tests

Cover:

- matching producer/consumer version succeeds;
- mismatched suite version produces the expected diagnostic;
- malformed/unsupported manifest schema still fails deterministically;
- package-smoke exercises the packed analyzer path.

## Focus Area D — Remove `SemanticTypeModel.Configuration.Generators`

### Purpose

Remove a speculative/placeholder package that has no implemented product capability.

### Required removal

Delete the package project and placeholder implementation.

Remove it from all active surfaces, including as applicable:

- solution/project references;
- `eng/common.sh` canonical package inventory;
- build/package/publish loops;
- package-smoke expectations;
- public package tables/shared NuGet README;
- public usage/configuration guidance;
- source/package tests;
- repository docs that imply generated configuration helpers exist.

### Compatibility policy

Do not create a tombstone package, forwarding package, compatibility shim, or obsolete API solely to retain this package identity.

If actual configuration generation is needed later, introduce a new implementation intentionally at that time.

### Validation

- canonical package inventory contains only real publishable packages;
- package/docs consistency validation passes;
- no active documentation references the removed package.

## Focus Area E — Remove JSON Schema import compatibility

### Purpose

Make the supported authoring direction unambiguous:

```text
annotated .NET
    -> canonical TypeSchemaModel
    -> JSON Schema derivation/export
```

JSON Schema is not a second supported authoring source for the canonical semantic model.

### Required removal

Remove the retained JSON Schema import surface and associated tests/documentation.

This includes any importer implementation retained only for package compatibility and any public interface implementation that communicates JSON Schema as a supported canonical model source.

### Compatibility policy

Do not:

- mark it obsolete and keep it;
- move it to another compatibility package;
- retain a lossy importer only to avoid a breaking change.

This milestone intentionally prefers removal.

### Preserve

Keep JSON Schema:

- target-domain derivation;
- Draft 2020-12 export;
- consumer-facing JSON Schema projection behavior that flows from canonical STM semantics.

### Tests/docs

Update tests and public docs so there is no implication of JSON Schema -> canonical STM round-trip/import support.

## Focus Area F — Separate Configuration derivation from integration internally

### Purpose

Make the target-domain-model boundary visible in source without introducing another package.

Preferred organization:

```text
SemanticTypeModel.Configuration/
    Domain/
        ConfigurationSemanticModel...
        ConfigurationDerivation...
    Options/
        SemanticOptionsRegistration...
        OptionsRegistrationExtensions...
```

Exact filenames may follow current repository conventions.

### Requirements

- no public behavior change unless required by source move;
- no new abstraction layer merely for symmetry;
- derivation remains target-domain logic;
- `IServiceCollection` / `OptionsBuilder<T>` integration remains explicit application-owned composition.

### Tests

Existing behavior must remain covered after source organization changes.

## Focus Area G — Audit post-EF ownership boundaries

### Purpose

Verify that other packages already conform to the architectural lesson from the EF rewrite rather than rewriting them pre-emptively.

### Audit packages

At minimum:

- `SemanticTypeModel.Abstractions`;
- `SemanticTypeModel.Core`;
- `SemanticTypeModel.DotNet`;
- `SemanticTypeModel.SystemTextJson`;
- `SemanticTypeModel.PowerBI`;
- `SemanticTypeModel.DependencyInjection`;
- `SemanticTypeModel.Configuration`;
- `SemanticTypeModel.JsonSchema`.

### Expected outcome

Most packages should be no-op.

Only change a package when current code contradicts these boundaries:

- canonical meaning remains projection-neutral;
- target packages derive target-specific representation;
- application owns global host/framework composition;
- projection integration is explicit and bounded;
- normal host framework extension mechanisms remain available to the application.

Do not create generic host/projection abstractions to encode these rules.

## Documentation Changes Required During Implementation

Update directly contradicted authority in the same milestone.

At minimum, ensure current authority states:

1. semantic manifest is ephemeral internal compile-time transport;
2. exact suite-version matching is required for manifest producer/consumer packages;
3. `SemanticTypeModel.Configuration.Generators` no longer exists;
4. JSON Schema import is no longer a supported API/capability;
5. engineering commands retain stable `eng/` names while complex command semantics live in tested code;
6. post-EF projection ownership principles are represented in architecture/current rationale where they are not already explicit.

Do not turn this into a broad prose cleanup. Record additional normalization work in `.guide-sync/pending/`.

## Documentation Sync

Use:

- `.guide-sync/pending/m0061-guide-system-and-post-ef-consolidation.md`

The hint is for remaining normalization only. Directly false current authority must be corrected during implementation.

## Validation Plan

### During implementation

Use Tier 1 focused validation for each affected subsystem.

Examples:

```sh
./eng/test-project.sh <affected-test-project>
./eng/test-filter.sh <focused-term>
```

Use the current command form while the command migration is in progress; validate the replacement command host directly where appropriate.

### Completion

Run:

```sh
./eng/check.sh
```

Also run focused validation for:

- generator/manifest tests;
- EFCore generator tests;
- JSON Schema tests;
- Configuration tests;
- engineering-command tests.

Then run package/public surfaces affected by removals and analyzer changes:

```sh
./eng/public-docs.sh
./eng/package.sh <validation-version>
./eng/package-smoke.sh <validation-version>
```

Use a non-publishing validation version appropriate to repository conventions.

If command migration changes release/package orchestration, also run:

```sh
./eng/samples.sh
./eng/release-check.sh <validation-version>
```

Do **not** publish.

### Required assertions

- `.guide-profile.json` parses;
- no copied external guide files exist;
- no `.review/` subsystem was added;
- Configuration.Generators is absent from canonical package inventory;
- active docs do not reference Configuration.Generators;
- active docs/API do not advertise JSON Schema import;
- manifest version mismatch produces deterministic diagnostic;
- matching packed generators work through package smoke;
- shell launchers migrated to the command host preserve arguments/exit status;
- engineering semantics moved to .NET have focused tests;
- `git diff --check` passes.

## Human Review

Formal `.review/` infrastructure is not activated.

Human review for M0061 is the normal repository review of:

- removal scope;
- public/breaking API impact;
- engineering command architecture;
- manifest mismatch diagnostic and behavior;
- documentation accuracy.

Do not fabricate formal review records.

## Non-goals

Do not:

- add new semantic features;
- reopen the EF Core generated-configuration architecture;
- add general EF relationship inference or provider-specific mapping;
- introduce a generic projection framework;
- convert every projection to source generation;
- make the semantic manifest public;
- add stored-manifest compatibility;
- activate resumable validation without a demonstrated need;
- add Windows/PowerShell support merely for parity;
- add a formal review subsystem;
- publish a release.

## Completion Criteria

M0061 is complete when:

- guide metadata is v0.6.0;
- repository-local authority remains the only implementation authority;
- complex engineering command semantics identified in scope have moved to tested code while `eng/` remains the stable API;
- semantic manifest producer/consumer exact-version enforcement is implemented and tested;
- `SemanticTypeModel.Configuration.Generators` is removed from source, package inventory, tests, and docs;
- JSON Schema import compatibility surface is removed from source, tests, and docs;
- Configuration derivation/integration source boundaries are clearer without a package proliferation;
- audited projection packages do not violate the post-EF ownership rules;
- Tier 2 and required package/public validation pass;
- no release is published;
- documentation-sync hint is either resolved or contains only genuine deferred normalization;
- after durable truth is synchronized, delete this completed milestone and return `docs/MILESTONES.md` to no-active-milestone state with M0062 next.
