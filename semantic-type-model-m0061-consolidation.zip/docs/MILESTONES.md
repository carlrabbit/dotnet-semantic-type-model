# Milestones

## Purpose

Milestones are **active implementation work orders**. They route an implementation agent to the scope, authority, acceptance criteria, and validation needed for the next coherent change.

Milestones are not permanent project truth.

## Current

- `M0061` — `docs/milestones/m0061-guide-system-and-post-ef-consolidation.md`

M0061 combines the guide-system v0.6.0 migration with the small repository, engineering-command, manifest, and package-boundary cleanups identified after the EF Core architecture rewrite.

## Next Number

```text
M0062
```

Never restart or reuse milestone numbers. Historical commit/PR/conversation references must remain unambiguous.

## Lifecycle

```text
plan
  -> active docs/milestones/mNNNN-*.md
  -> implement
  -> synchronize durable truth
  -> validate
  -> complete
  -> delete completed milestone file
```

Before deleting a completed milestone, promote durable outcomes as appropriate:

- current behavior -> specification;
- structural change -> architecture;
- enduring non-obvious rationale -> decision;
- consumer-visible behavior -> public/package documentation;
- architectural evolution -> concise `HISTORY.md` entry when warranted;
- regression contract -> tests.

Do not move completed milestones into an archive directory. Git history retains them.

## Milestone Creation Rule

Create a milestone only for active implementation sequencing. Do not create milestone files to preserve release history, completed implementation notes, or documentation that belongs in a current subsystem contract.
