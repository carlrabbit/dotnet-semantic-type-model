# MILESTONES.md Update

Append this entry after M0054:

```text
- [M0055 - Opinionated Relational Projection Contract and EF Core Package Reset for 2.5.0](milestones/m0055-opinionated-relational-projection-contract-and-ef-core-package-reset-for-2-5-0.md)
```
