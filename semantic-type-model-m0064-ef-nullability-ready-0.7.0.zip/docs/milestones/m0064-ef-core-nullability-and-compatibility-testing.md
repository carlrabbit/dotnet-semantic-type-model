# M0064 — EF Core Nullability and Compatibility Testing

## Execution Profile

| Field | Value |
|---|---|
| Lifecycle state | ready |
| Mode | ai-executed-broad |
| Scope size | medium-large |
| Implementation autonomy | high |
| Documentation sync | deferred except directly contradicted authority |
| Local validation | Tier 1 focused validation |
| Integration validation | Tier 2 repository check + Tier 3 packed-package smoke |
| Human review | none |

## Goal

Fix the published 4.0.0 EF Core regression where a nullable owned JSON property can generate a non-nullable converter/comparer generic type and fail consumer compilation, then restructure the EF compatibility tests and fixtures so storage-shape/nullability regressions are covered systematically across projection, generation, finalized EF metadata, provider behavior, and packed-package consumption.

The fix must remain patch-compatible and suitable for a 4.0.1 follow-up release. Release readiness and publication are separate work.

## Target State

When M0064 is complete:

1. nullable owned JSON object properties generate EF configuration that compiles with the declared nullable CLR property type;
2. nullable owned JSON collection properties obey the same property-nullability rule;
3. storage classification may normalize a type internally without erasing nullable-reference syntax required by generated generic EF APIs;
4. required owned JSON mappings remain unchanged;
5. the EF test system follows the four-layer architecture and matrix defined in `docs/engineering/ef-core-testing.md`;
6. successful generator compatibility cases use the real STM generator -> manifest -> EF generator chain rather than synthetic manifests alone;
7. real EF model finalization verifies converter/comparer/nullability metadata for the affected shapes;
8. SQLite tests cover nullable-owned state transitions;
9. packed NuGet smoke includes a nullable-owned generated EF consumer;
10. durable EF test/fixture naming describes product behavior rather than milestone history where M0064 restructures those surfaces;
11. the existing multi-model/manual-entity scenario remains covered as a composition smoke test;
12. no new public API or new semantic relationship/storage model is introduced.

## Scope

### Nullable generated-type regression

Correct generated C# for nullable owned JSON properties.

The reported failing shape is equivalent to:

```csharp
public WebServiceSourceConfiguration? Configuration { get; set; }
```

The generated converter/comparer use must be type-compatible with:

```text
PropertyBuilder<WebServiceSourceConfiguration?>
```

and must not collapse the model-side generic type to `WebServiceSourceConfiguration` merely because storage classification treats nullable and non-nullable references as the same runtime CLR type.

### Owned JSON object and collection property nullability

Cover both:

```text
required owned object
nullable owned object

required owned collection
nullable owned collection
```

This milestone concerns property/container nullability.

Do not invent a new nullable-item semantic contract for collection elements.

### EF compatibility matrix

Implement the durable coverage contract in `docs/engineering/ef-core-testing.md`.

The implementation may choose parameterized data, helper records, fixture classes, shared test utilities, or another idiomatic TUnit structure.

### Fixture/test consolidation

Rework the current EF fixture/test surfaces enough that:

- valid compatibility scenarios can flow from annotated CLR source through the relevant layers;
- hand-built canonical models remain useful for pure projection/invalid-state tests;
- synthetic manifests remain useful for generator error isolation;
- composition smoke remains distinct from property-shape matrix coverage;
- touched milestone-named EF tests/fixtures are normalized to behavior-oriented names.

Exact file/project layout is implementation-owned.

### Packed package smoke

Extend the current packed EF generator consumer so nullable owned JSON compilation is exercised from locally packed packages.

## Non-goals

- new EF relationship semantics;
- `OwnsOne` / `OwnsMany`;
- provider-specific JSON query features;
- a new JSON storage policy;
- nullable collection-item semantics;
- changes to canonical semantic nullability rules;
- public converter/comparer API redesign unless the existing API cannot implement the approved behavior without a compatibility change;
- broad test-framework migration;
- replacing TUnit or Microsoft Testing Platform;
- introducing a second EF provider solely for this regression;
- broad renaming outside the EF test/fixture system touched by this work;
- release preparation, NuGet publication, tag creation, or GitHub Release creation;
- unrelated guide-system migration beyond the 0.6 -> 0.7 profile/lifecycle normalization included in this overlay.

## Decisions and Constraints

- **Patch compatibility:** preserve the 4.0 public API unless a concrete blocker is discovered. The intended consumer fix belongs in a 4.0.1 patch line.
- **Declared property type matters:** when generated EF generic APIs represent the CLR property model type, generated C# must preserve nullable-reference modifiers from the actual property symbol.
- **Classification is separate:** storage classification may unwrap/normalize types for choosing a mapping strategy, but that normalized type must not replace the declared property type in generic APIs that require exact nullability.
- **No runtime-nullability protocol:** do not redesign the semantic manifest or converter API merely to encode nullable-reference annotations that Roslyn already knows at generation time unless implementation proves the current architecture cannot preserve correctness.
- **Real-chain success tests:** supported successful mappings must not rely exclusively on a hand-authored synthetic manifest.
- **Synthetic manifests remain valid for failure isolation:** malformed/version/collision/missing-symbol diagnostics should stay cheap and isolated.
- **Real EF boundary:** metadata/converter/comparer behavior must be checked after actual EF model finalization.
- **Provider transitions:** nullable owned JSON must prove `null -> value -> changed value -> null` behavior with SQLite.
- **Package boundary:** packed analyzer/generator consumption is mandatory because the defect is consumer-compilation visible.
- **No one-off-only fix:** adding one regression test without repairing the matrix/test architecture is insufficient.
- **No exhaustive Cartesian explosion:** the matrix defines intentional coverage; implementation should use representative/provider cases and parameterization rather than hundreds of redundant tests.

## Required Authority

Read only:

- `AGENTS.md`
- `docs/SPECS.md`
- `docs/specs/ef-core.md`
- `docs/ENGINEERING.md`
- `docs/engineering/dotnet.md`
- `docs/engineering/command-contract.md`
- `docs/engineering/ef-core-testing.md`
- `docs/engineering/packaging.md`
- `docs/MILESTONES.md`
- the current EF Core decision/architecture documents routed by `docs/DECISIONS.md` / `docs/ARCHITECTURE.md` only if concrete implementation work touches those boundaries
- public EF/compatibility documentation only when implementation directly contradicts it

Implementation should inspect the live source/test/fixture/package-smoke code needed to make the change. The milestone intentionally does not prescribe exact class/function/file edits.

Do not read the external guide repository, planning transcript, `.guide-profile.json`, or `.guide-sync/` during ordinary implementation.

## Likely Affected Areas

These are navigation hints, not a required edit list:

```text
src/SemanticTypeModel.EFCore.Generators/
src/SemanticTypeModel.EFCore/
tests/unit/SemanticTypeModel.EFCore.Generators.Tests.Unit/
tests/unit/SemanticTypeModel.EFCore.Tests.Unit/
tests/integration/SemanticTypeModel.EFCore.Tests.Integration/
tests/fixtures/
tests/package-smoke/
eng/Engineering.Commands/PackageSmokeRunner.cs
docs/specs/ef-core.md
public EF/release documentation only if directly contradicted
```

## Acceptance Criteria

### Regression

- a nullable owned JSON object fixture reproduces the 4.0.0 failure before the fix and compiles after the fix;
- generated converter/comparer generic model types are compatible with nullable property builders;
- required owned object behavior remains correct;
- nullable owned collection properties compile under the same rule;
- repository nullable-reference/warnings-as-errors policy remains enabled.

### Four-layer matrix

- Layer 1 includes deliberate required/nullable coverage for supported storage families;
- Layer 2 includes real-chain generated compilation for required/nullable owned JSON object and collection properties;
- Layer 3 inspects finalized EF metadata for affected nullable/required converter mappings;
- Layer 4 exercises required provider transitions for nullable owned JSON;
- inheritance/reuse coverage proves property-use nullability is not attached globally to the structural value type;
- multi-model/manual-entity composition coverage remains intact.

### Fixture architecture

- successful mapping fixtures are not duplicated as independently maintained CLR + canonical truths unless a test explicitly isolates Layer 1;
- synthetic manifest success tests are no longer the only proof of supported mapping shapes;
- touched `M0060...` EF test/fixture names are normalized to behavior-oriented durable names;
- compatibility-matrix fixtures and real-world/composition fixtures have distinct purposes.

### Package smoke

- `package-smoke` builds a packed-package consumer with a nullable owned JSON property through both generator packages;
- package smoke fails if the nullable generic mismatch regresses;
- the full packed-package smoke still validates the existing package inventory and consumer scenario.

### Documentation

- `docs/specs/ef-core.md` is updated with the durable generated-type/nullability invariant if current wording does not already make it explicit;
- `docs/engineering/ef-core-testing.md` remains consistent with implemented tests;
- no current authority claims that synthetic manifest or hand-built canonical tests alone prove boundary-crossing EF behavior.

### Compatibility

- no intentional public API break is introduced;
- no compatibility shim or new public abstraction is added solely to work around the generator defect;
- the change is suitable for a 4.0.1 patch release.

## Validation

### Tier 0

For documentation/static edits:

```sh
git diff --check
```

Run formatter verification through the repository's normal Tier 2 gate; do not invent alternate format commands.

### Tier 1 — focused EF validation

Run all affected EF test projects:

```sh
./eng/test-project.sh tests/unit/SemanticTypeModel.EFCore.Generators.Tests.Unit/SemanticTypeModel.EFCore.Generators.Tests.Unit.csproj
./eng/test-project.sh tests/unit/SemanticTypeModel.EFCore.Tests.Unit/SemanticTypeModel.EFCore.Tests.Unit.csproj
./eng/test-project.sh tests/integration/SemanticTypeModel.EFCore.Tests.Integration/SemanticTypeModel.EFCore.Tests.Integration.csproj
```

Use focused selectors such as:

```sh
./eng/test-filter.sh Nullable
./eng/test-filter.sh Owned
./eng/test-filter.sh EFCore
```

when useful during iteration.

### Tier 2 — repository completion gate

Required:

```sh
./eng/check.sh
```

### Tier 3 — packed generator boundary

Use a local non-publishing patch-candidate version:

```sh
./eng/package.sh 4.0.1-m0064
./eng/package-smoke.sh 4.0.1-m0064
```

Both commands must complete successfully.

Publishing is out of scope.

## Validation Execution Mode

| Validation | Mode |
|---|---|
| Tier 1 EF projects | direct |
| Tier 2 repository check | direct aggregate |
| Tier 3 package/package-smoke | direct aggregate |
| Human review | not applicable |

The repository does not currently expose resumable sharding for these commands. Partial child output is not aggregate success.

## Constrained Runtime Handling

If a constrained implementation environment cannot complete `./eng/check.sh` or packed-package smoke:

1. continue focused Tier 1 work for diagnosis;
2. do not claim completion from partial output;
3. run the unchanged aggregate command in a capable environment/CI;
4. require its complete successful result before marking M0064 done;
5. record the successful aggregate evidence in the implementation completion summary.

Do not add resumable-validation infrastructure as part of this bugfix/test-architecture milestone.

## Human Review

Applicability: `none`.

Automated compilation, EF metadata assertions, SQLite transitions, Tier 2, and packed-package smoke can decide the milestone's acceptance criteria.

No `.review/` request or record is required.

## Direct Documentation Impact

During implementation, update only documentation directly contradicted by the corrected behavior/test architecture.

At minimum verify:

- `docs/specs/ef-core.md`;
- `docs/engineering/ef-core-testing.md`.

Do not turn M0064 into a broad documentation reset.

## Deferred Documentation Synchronization

Residual consumer/release synchronization is tracked in:

```text
.guide-sync/pending/m0064-ef-core-nullability-and-compatibility-testing.md
```

Ordinary implementation does not read that file.

## Guide-System Migration Included in the Overlay

The overlay updates repository guide metadata from 0.6.0 to 0.7.0 and normalizes the milestone lifecycle to:

```text
draft/planning -> ready -> implementing -> done
```

This is workflow metadata only.

Do not rewrite valid product truth merely to describe guide-system methodology.

Do not perform any other guide migration work unless implementation discovers a direct repository-local contradiction.

## Escalation Boundary

Implementation owns concrete source edits, helper design, fixture layout, parameterization technique, test class/file organization, and refactoring mechanics that satisfy this contract.

Return M0064 to planning if implementation discovers that completing the fix requires any material new decision about:

- canonical semantic nullability;
- collection item nullability;
- converter/comparer public API compatibility;
- semantic manifest compatibility/versioning;
- provider-neutral JSON storage policy;
- supported EF relationship/storage semantics;
- patch-versus-breaking compatibility;
- validation policy.

A local choice about Roslyn display formatting, helper placement, fixture class names, or parameterized-test mechanics is implementation-owned and must not be escalated.
